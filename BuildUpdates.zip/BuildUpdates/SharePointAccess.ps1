#**************************************************************
#	Script Name: SharePointAccess
#	Purpose: Script will upload the documents/files to share point and performs check-out/check-ins
#			 and Download files
#	Pre-Req: Microsoft.SharePoint.Client
#			 Microsoft.SharePoint.Client.RunTime
#			 All Share point DLL's are copied from share point server and Draged to GAC "C:\Windows\Assembly"
#			 PowerShell V3 is required to run the script
#	Author:  Navya K.M
#
#*************************************************************
[CmdletBinding()] 
		param (
			[parameter(Mandatory=$true,HelpMessage="SharePoint URL till sites")][string]$SPUrl,
			[parameter(Mandatory=$true,HelpMessage="Documents Folder")][string]$docfolder,
			[parameter(Mandatory=$true,HelpMessage="SharePoint UserName")][string]$User,
			[parameter(Mandatory=$true,HelpMessage="SharePoint Password")][string]$Password,
			[parameter(Mandatory=$true,HelpMessage="download-DownLoadFile,upload-UploadFile,list-'To list files'")][string]$flag,
			[parameter(Mandatory=$true,HelpMessage="Log file to enter data")][string]$logfile,
			[parameter(Mandatory=$false,HelpMessage="DestinationFolder")][string]$TargetFolder,
			[parameter(Mandatory=$false,HelpMessage="FileToUpload/FileToDownload")][string]$TargetFile
			)

#Declare Global Variables			
$spContext			


#-----------------------------------------------------------------------------
# Function: Main
# This is main function which calls 'connectsharepoint' func, 
# It Re-tries to establish SharePoint connection for 3 times when there is 
# connection failure
#------------------------------------------------------------------------------
function main()
{	
	#Create log file if it does not exists
	If (!(Test-Path $logfile)) {
		New-Item -ItemType file -Path $logfile | Out-Null
	}
	WriteLog "************Script Execution Started**************"
	importdlls
	WriteLog "Try to Connect SharePoint"
	$connect=connectsharepoint	$SPUrl	$User	$password
	if ($connect)
	{
		WriteLog "Sharepoint Connection Established... Perform further Tasks"
		PerformTasks	
	}
	else{
		  WriteLog "Sharepoint Connection is Failing................Retry again"
		  $count=3
		  for ($i=1; $i -le $count; $i++)
		  {
			WriteLog "$i iteration Trying to connect"
			$connect=connectsharepoint	$SPUrl	$User	$password
			if($connect)
			{
			  WriteLog "connection established at $i iteration"
			  PerformTasks
			  break;
			}
		  }
		}
}	
#-----------------------------------------------------------------------------
# Function: PerformTasks
# It performs various tasks based on flag specified by user and returns output
# List: listing all files/folders in SharePoint site
# Upload : Upload files to SharePoint 
# Download : Download file from SharePoint to local system
#------------------------------------------------------------------------------
function PerformTasks
{
	if ($flag -eq "download")
		{
			If (!(Test-Path $TargetFolder)) {New-Item -ItemType directory -Path $TargetFolder | Out-Null}
			$value=DownloadFiles	$docfolder	$TargetFolder	$TargetFile
			$spContext.dispose()
			return $value
		}
		if ($flag -eq "upload")
		{
			#UploadFiles "Documents" "C:\users\Administrator\desktop\test1" "triggerNotes.txt"
			$retvalue2=Check-OutFiles	"$docfolder"	$TargetFile
            $retvalue1=UploadFiles	"$docfolder"	$TargetFolder	$TargetFile
			$retvalue3=Check-InFiles	"$docfolder"	$TargetFile
			$spContext.dispose()
			if ($retvalue1 -and $retvalue2 -and $retvalue3)
			{
				return $True
			}else{
			return $False
			}	
		}
		if ($flag -eq "list")
		{
			#ListFiles "Documents" "C:\users\Administrator\desktop\test1"
			$FileList=@()
			$FileList=ListFiles	$docfolder
			$spContext.dispose()
			return $FileList
		}
}
#-----------------------------------------------------------------------------
# Function: WriteLog
# It writes data to log file with time stamp
#------------------------------------------------------------------------------
function WriteLog {
	Param(
	[Parameter(Mandatory=$true)][string]$LineValue
	)
	$starttime = Get-Date -uformat "%d/%m/%Y %H:%M:%S"
	$line = $starttime+ " : "+$LineValue
	Add-Content -Path $logfile -Value $line
	#Write-Host $LineValue
}
#-----------------------------------------------------------------------------
# Function: importdlls
# It loads/registers required .Net assembly list 
#------------------------------------------------------------------------------
function importdlls
{
	$assemblylist= "Microsoft.SharePoint.Client","Microsoft.SharePoint.Client.Runtime",
	"Microsoft.SharePoint.Client.Taxonomy","Microsoft.SharePoint.Client.Publishing"
	
	foreach ($asm in $assemblylist)
	{
	   $asm = [Reflection.Assembly]::LoadWithPartialName($asm)
	   WriteLog "Loaded Assembly Name: $asm"
	}
}
#-----------------------------------------------------------------------------
# Function: connectsharepoint
# It establishes connection to SharePoint using credentials as input and 
# gives return code
#------------------------------------------------------------------------------
function connectsharepoint{
	Param(
	[string]$SPUrl,
	[string]$User,
	[string]$password
	)
	$securePassword = ConvertTo-SecureString $password -AsPlainText -Force
	#[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
	
	$clientContext = New-Object Microsoft.SharePoint.Client.ClientContext($SPUrl)
	if($SPUrl.Contains(".sharepoint.com")) # SharePoint OnLine
	{    
		Write-Host "THIS IS SHAREPOINT ONLINE"
		$credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($User, $securePassword)
		$clientContext.Credentials = $credentials
		if (!$clientContext.ServerObjectIsNull.Value) 
		{ 
			Write-Host "Connected to SharePoint Online site: '$SPUrl'" -ForegroundColor Green
			Set-Variable -Name "spContext" -Value $clientContext -Scope Global
			return $true
		}
		else{
			Write-Host "NOT CONNECTED TO SharePoint" -ForegroundColor Red
			return $false
			exit 1
		}
	}
	 else # SharePoint On-premises
	{
		$Domain=$User.Split("/\")[0]
		$UserName=$User.Split("/\")[1]
		$credentials = New-Object System.Net.NetworkCredential($UserName,$securePassword,$Domain)
		$clientContext.Credentials = $credentials
		#$clientContext.AuthenticationMode = [Microsoft.SharePoint.Client.ClientAuthenticationMode]:Default
		$clientContext.RequestTimeOut = 5000 * 60 * 10;
		$web = $clientContext.Web
		$site = $clientContext.Site
		$clientContext.Load($web)
		$clientContext.Load($site)
		try
		 {
			$clientContext.ExecuteQuery()
			WriteLog "Established connection to SharePoint at $SPUrl OK"
			Set-Variable -Name "spContext" -Value $clientContext -Scope Global
			return $true
		 }
		 catch
		 {
			WriteLog "Not able to connect to SharePoint at $Url. Exception:$_"
			return $false
			exit 1
		 }
	}
	
}
#-----------------------------------------------------------------------------
# Function: UploadFiles
# It uploads files to SharePoint link.
# gives return code
#------------------------------------------------------------------------------
function UploadFiles
{
	param(
		[string] $docfolder,
		[string] $sourcedir,
		[string] $filetoupload
		)
	try
	{
		[Microsoft.SharePoint.Client.Web]$web = $spContext.Web
		[Microsoft.SharePoint.Client.List]$list = $web.Lists.GetByTitle($docfolder)
		foreach ($File in (dir $sourcedir))
		{
			if ($File.Name -eq $filetoupload)
			{
				WriteLog "File to be uploaded to SharePoint : $File"
				$FileCreationInfo = New-Object Microsoft.SharePoint.Client.FileCreationInformation
				$FileCreationInfo.Overwrite = $true
				$FileCreationInfo.Content = get-content -encoding byte -path $File.Fullname
				$FileCreationInfo.URL = $File
				$Upload = $list.RootFolder.Files.Add($FileCreationInfo)
				$spContext.Load($Upload)
				try
				{
					$spContext.ExecuteQuery()
					WriteLog "Uploading  File $filetoupload  is successful to SharePoint at $SPUrl OK"
					return $true
				}
				catch
				{
					WriteLog "Not able to Upload File to SharePoint at $web. Exception:$_.Exception.Message"
					return $false
				}
			}
		}
		return $true
	}
	catch {
		WriteLog "Error in Upload File to SharePoint at $web. Exception:$_.Exception.Message"
		return $false
	}
	
}
#-----------------------------------------------------------------------------
# Function: Check-InFiles
# To check-in files after upload to SharePoint link.
# gives return code
#------------------------------------------------------------------------------
function Check-InFiles
{
	param(
		[string]$docfolder,
		[string]$targetfile
		)
		$flag=$True
		[Microsoft.SharePoint.Client.Web]$web = $spContext.Web
		$lists=$web.Lists.GetByTitle($docfolder)
		$query=[Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery(1000)
		$result =$lists.GetItems($query)
		$spContext.Load($lists)
		$spContext.Load($result)
		$spContext.ExecuteQuery()
		foreach ($i in $result)
		{
			$item = $lists.GetItemById($i.Id)
			$file=$item.File
			#$versionColl=$item.File.Versions;
			$spContext.Load($item);            
			$spContext.Load($file);            
			#Execute the query to get the items we loaded            
			$spContext.ExecuteQuery()
			#Create the Url for the file            
			$itemUrl = ([String]::Format("{0}{1}",$SourceWebApplicationUrl,$item["FileRef"]));              
			$fileName = $itemUrl.Substring($itemUrl.LastIndexOf("/")+1);
			if ($fileName -eq $targetfile)
			{
				WriteLog "File '$fileName' version $file.Level"
				#if ($file.Level -eq [Microsoft.SharePoint.SPFileLevel]::Checkout)
				if ($file.Level -eq "Checkout")
				{
					WriteLog "File $fileName needs to checked -in"
					$file.CheckIn("Checked in from Automation Script", [Microsoft.SharePoint.Client.CheckInType]::MajorCheckIn);
					$spContext.ExecuteQuery()
					WriteLog "File $fileName is Checked In Successfully"
				}else{
					$flag=$false
				}
			}
		}
	return $flag	
}
#-----------------------------------------------------------------------------
# Function: Check-OutFiles
# To checkOut files after upload to SharePoint link.
# gives return code
#------------------------------------------------------------------------------

function Check-OutFiles
{
	param(
		[string]$docfolder,
		[string]$targetfile
		)
		$flag=$True
		[Microsoft.SharePoint.Client.Web]$web = $spContext.Web
		$lists=$web.Lists.GetByTitle($docfolder)
		$query=[Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery(1000)
		$result =$lists.GetItems($query)
		$spContext.Load($lists)
		$spContext.Load($result)
		$spContext.ExecuteQuery()
		foreach ($i in $result)
		{
			$item = $lists.GetItemById($i.Id)
			$file=$item.File
			#$versionColl=$item.File.Versions;
			$spContext.Load($item);            
			$spContext.Load($file);            
			#Execute the query to get the items we loaded            
			$spContext.ExecuteQuery();
			#Create the Url for the file            
			$itemUrl = ([String]::Format("{0}{1}",$SourceWebApplicationUrl,$item["FileRef"]));              
			$fileName = $itemUrl.Substring($itemUrl.LastIndexOf("/")+1);
			if ($fileName -eq $targetfile)
			{
				WriteLog "File is found : $fileName"
				if ($file.CheckOutType -eq [Microsoft.SharePoint.Client.CheckOutType]::None)
				{
					WriteLog "Target file $fileName needs be check out"
					$file.CheckOut();
					$spContext.Load($file);
					$spContext.ExecuteQuery();
					WriteLog "Target file $fileName checked out successfully"
				}
			}
		}
		
	return $flag		
}

#-----------------------------------------------------------------------------
# Function: DownloadFiles
# To Download Files from SharePoint link and gives return code
# 
#------------------------------------------------------------------------------
function DownloadFiles
{
	param(
		[string]$docfolder,
		[string]$destpath,
		[string]$targetfile
		)
	try
	{
		[Microsoft.SharePoint.Client.Web]$web = $spContext.Web
		$lists=$web.Lists.GetByTitle($docfolder)
		$query=[Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery(1000)
		$result =$lists.GetItems($query)
		$spContext.Load($lists)
		$spContext.Load($result)
		$spContext.ExecuteQuery()
		foreach ($i in $result)
		{
			$item = $lists.GetItemById($i.Id)
			$file=$item.File
			$spContext.Load($item);            
			$spContext.Load($file)           
			#Execute the query to get the items we loaded            
			$spContext.ExecuteQuery()
			#Create the Url for the file            
			$itemUrl = ([String]::Format("{0}{1}",$SourceWebApplicationUrl,$item["FileRef"]));              
			$fileName = $itemUrl.Substring($itemUrl.LastIndexOf("/")+1);
			if ($fileName -eq $targetfile)
			{
				WriteLog "File name matched $fileName and Downloading it"
				try{
					$target=$destpath+"\"+$fileName
					WriteLog "Downloading file $itemUrl to path $target"; 
					[Microsoft.SharePoint.Client.FileInformation] $fileInfo = [Microsoft.SharePoint.Client.File]::OpenBinaryDirect($spContext,$itemUrl);
					[System.IO.FileStream] $writeStream = [System.IO.File]::Open($target,[System.IO.FileMode]::Create);
					$fileInfo.Stream.CopyTo($writeStream);
					$writeStream.Close();
					return $true
				}
				catch {
						WriteLog "Unable to Download File '$fileName' from SharePoint at $web. Exception:$_.Exception.Message"
						return $false
					}
			}
		}
	}
	catch {
			WriteLog "Not able to Download File from SharePoint at $web. Exception:$_.Exception.Message"
			return $false
		}
			
}
#-----------------------------------------------------------------------------
# Function: ListFiles
# To Lists all files from SharePoint link to an array.
# 
#------------------------------------------------------------------------------

function ListFiles
{
param(
		[string]$docfolder
		)
	$myFileList=@()
	[Microsoft.SharePoint.Client.Web]$web = $spContext.Web
	$lists=$web.Lists.GetByTitle($docfolder)
	$query=[Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery(1000)
	try
	{
		$result =$lists.GetItems($query)
		$spContext.Load($lists)
		$spContext.Load($result)
		$spContext.ExecuteQuery()
		foreach ($i in $result)
		{
			$item = $lists.GetItemById($i.Id)
			$file=$item.File
			#$clientContext.Load($versionColl)
			$spContext.Load($item);            
			$spContext.Load($file);            
			#Execute the query to get the items we loaded            
			$spContext.ExecuteQuery()
			#Create the Url for the file            
			$itemUrl = ([String]::Format("{0}{1}",$SourceWebApplicationUrl,$item["FileRef"]));              
			$fileName = $itemUrl.Substring($itemUrl.LastIndexOf("/")+1);
			<# foreach($version in $versionColl) { 
				if($version.IsCurrentVersion){$vers=$version.VersionLabel}
			} #>
			$file=$fileName
			$myFileList+=$file
			$myFileList+=','
		}
	}
	catch{
			WriteLog "Error in retrieving file list from share point Exception:$_."
		}
	return $myFileList
}
#-----------------------------------------------------------------------------
# Function: Clean-Memory
# To Release Variables at end of script execution.
# 
#------------------------------------------------------------------------------
function Clean-Memory {
Get-Variable |
 Where-Object { $startupVariables -notcontains $_.Name } |
 ForEach-Object {
  try { Remove-Variable -Name "$($_.Name)" -Force -Scope "global" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue}
  catch { }
 }
}
main
WriteLog "Releasing Memory"	
Clean-Memory
WriteLog "************Script Execution End**************"
exit

