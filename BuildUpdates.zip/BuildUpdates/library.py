#!C:\Python27

#####################################################
#
# libirary.py
#
# Copyright 2015 Hewlett-Packard Development Company.
#
# Hewlett-Packard and the Hewlett-Packard logo are trademarks of
# Hewlett-Packard Development Company, in the U.S. and/or other countries.
#
# Confidential computer software. Valid license from Hewlett-Packard required
# for possession, use or copying. 
#       
#       Creation date   : 2014/12/11
#       Last Modified   : 2015/03/09
#       Author          : Thejasvy.MV
#       Project         : HP Printer Automation
#       Description     : This is a general purpose library module implemented to use for logging the reports, 
#                         reading the excel data, reading config file of header and data of given regex format,
#                         triggering multithreads of userdefined threadlimits for the already created threadlists 
#
#       Class           : Reportlogs,ReadData,Misc
#       Component       : library
#       Affects version : v1.1.0 and newer
#       Tested          : OK
##########################################################

try:
    import os
    import re
    import sys
    import time
    import xlrd  #xlrd module is required to read excel file which is a prerequisite
    import win32api
    import threading
    import collections  #required if same order of data to be maintained
    import unicodedata
    import subprocess
    import win32com.client  #used to read and write excel data
    from pprint import pprint
    
except ImportError as e:
    print("The current module is not installed in your machine, Error: ", e)
    exit()
    
else:
    __scriptname__ = "library.py"
    __version__    = 1.1
    __author__     = "Thejasvy.MV"
    __owner__      = "Hewlett-Packard"
    
    
class Reportlogs():
    '''
    This class used for reporting all the logs to a logfile of userdefined directory name and filename.
    '''
    def __init__(self, dirname = "Logs", filename = "logfile"):
        '''
        REQUIRES:
        
        Input: dirname type string where used defined directories would be created in existing script path else default names would be considered
        filename: logfile type string where logfile name would begin with the user mentioned name else default names would be considered
        
        PROMISE:
        
        This constructor of class reportlogs accepts directoryname,filename and creates
        logfile with path where library file been placed within directory name with file
        name logfile_dd_mm_yyyy.log if directory and filename already presents it wil overrite
        Returns: None

        '''
        self.filename = filename
        self.scriptpath, self.scriptname = os.path.split(os.path.abspath(__file__))
        self.cwd = os.getcwd()
        #self.logfilepath = os.getcwd()+"\\"+dirname  #log file will be created in current executing diretory
        self.logfilepath = self.scriptpath+"\\"+dirname    #log file will be created where library.py script is present
        if(os.path.exists(self.logfilepath) is False):
            os.mkdir(self.logfilepath)
        self.logfile = self.logfilepath +"\\"+ self.filename+ time.strftime("__%d-%m-%Y_%H-%M-%S.log")
        if(os.path.exists(self.logfilepath)):
            fout = open(self.logfile,"a+")
            #fout.write("{0} : Log creation time\n".format(time.strftime("%d-%m-%Y %H:%M:%S")))
            fout.close()
            
    def __str__(self):
        '''
        REQUIRES:
        Input: None
        
        PROMISE:
        special variable been overridden to display logfile path and logile name
        Returns: res type string
        '''
        if(self.logfilepath):
            res = "Find your logs in path:  %s\nYour Logfile name is : %s\n" % (self.logfilepath, os.path.basename(self.logfile))
            return res
    
    def writelog(self, data):
        '''
        REQUIRES:
        
        Input: data type string contains collection of string to be logged to logfile
        
        PROMISE:
        
        Method used to log the message present in variable data to the logfile with timestamp format dd/mm/yyyy HH:MM:SS : 
        Returns: None
        '''
        locked = threading.Lock()
        locked.acquire()
        if(os.path.exists(self.logfilepath) and data):
            fout = open(self.logfile,"a+")
            t = time.strftime("%d/%m/%Y %H:%M:%S : ")
            fout.write(str(t) + str(data) + "\n")
            fout.close()
        else:
            #self.writelog( "Unable to write log!")
            print("Unable to write log!")
        locked.release()

class ReadData():
    '''
    This Class will construct Schedule updates object and performs the required operations like read excel data, create registry file, copy to servers and update execute it
    '''
    def __init__(self, **kwargs):
        '''
        REQUIRES:
        Input: dict
        
        PROMISE:
        to hold the given dicts in the object instance.
        Returns: None
        '''
        if(kwargs):
            self.kwargs = kwargs
            
    def __str__(self):
        '''
        REQUIRES:
        Input None
        
        PROMISE:
        
        special variable been overridden to display given file name and constructed dictionary
        Returns: res type string
        '''
        if(self.datalist):
            res = "Given FileName is: {0}\nLIST OF DICTIONARIES OF GIVEN DATA: {1}".format(self.filename,self.datalist)
            return res
        else:
            res = "Given FileName is: {0}".format(self.filename)
            return res
            
    def readExcel(self, excelfile, sheetname = "Sheet1"):    # implemented using xlrd module
        '''
        REQUIRES:
        
        Input: excelfile string type path to excel to be passed
        sheetname: strign type which sheet in excel to be opened
        
        PROMISE:
        
        Method used to open and read excel file and builds dictionary of headers and values (xlrd module is required)
        NOTE: method assumes Excel data begin with first row first column
        Returns: dict
        '''
        finaldata = []
        if(os.path.exists(excelfile) and os.path.getsize(excelfile) > 1):
            workbook = xlrd.open_workbook(excelfile)
            try:
                worksheet = workbook.sheet_by_name(sheetname)
            except:
                print('"{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                return
            else:
                num_rows = worksheet.nrows - 1
                num_cells = worksheet.ncols - 1
                if(num_rows <= 0 or num_cells <= 0):
                    print('Sheet: "{0}" has no data in "{1}"'.format(sheetname,excelfile))
                    return
                curr_row = -1
                L=[]
                while (curr_row < num_rows):
                    curr_row += 1
                    row = worksheet.row(curr_row)
                    curr_cell = -1
                    tempD=[]
                    while (curr_cell < num_cells):
                        curr_cell += 1
                        # Cell Types: 0=Empty, 1=Text, 2=Number, 3=Date, 4=Boolean, 5=Error, 6=Blank
                        cell_type = worksheet.cell_type(curr_row, curr_cell)
                        cell_value = worksheet.cell_value(curr_row, curr_cell)
                        if(curr_row == 0):
                            L.append(cell_value)
                        if(curr_row > 0):
                            tempD.append(cell_value)
                    if(tempD):
                        tempdict = {}
                        for i in range(len(L)):
                            if(tempD[i]):
                                tempdict[L[i]] = tempD[i]
                            else: 
                                tempdict[L[i]] = None
                        finaldata.append(tempdict)
                        tempD=[]
            print("Using xlrd module.....\nList of dictionary of given data: ",finaldata,"\n\n")
            return  finaldata
        else:
            print(self.filename, " does not exist!")

    def readExcelWin32(self, excelfile, sheetname = "Sheet1", searchstring = '[a-zA-Z]{5,}', columns = 'All'):
        '''
        REQUIRES:
        
        Input: excelfile string type path to excel to be passed
        sheetname: string type which sheet in excel to be opened
        searchstring: type string where data header begins
        
        PROMISE:
        
        Method used to open and read excel file and builds dictionary of headers and values (win32com.client module is required)
        NOTE: Script is dynamic finds which row data begins and builds dict once row exists (first data existing row considered as headers)
        Returns: dict
        '''
        if(os.path.exists(excelfile)):
            try:
                result = self.check_process_status(application = 'excel.exe')
                print("excel running status;",result)
                excel = win32com.client.Dispatch("Excel.Application")
            except:
                print("Unable to open Excel application, Check if the application is installed and working fine.")
                os._exit(1)
            else:
                try:
                    abspath = os.path.abspath(excelfile)
                    book = excel.Workbooks.Open(abspath)
                    if(sheetname == "Sheet1"):
                        sheetname = book.ActiveSheet.name
                except:
                    print("Excel file is already opened please close then run the script!")
                    os._exit(1)
                else:
                    finaldata = []
                    excel.Visible = True
                    try:
                        sheet = book.Sheets(sheetname)
                    except:
                        print('"{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                        excel.Quit() 
                        return
                    else:
                        excel.DisplayAlerts=True
                        used=sheet.UsedRange
                        headercount = 0
                        headers = []
                        flag = 0
                        for row in range(used.Rows.Count):
                            headercount += 1
                            mobj = re.search(searchstring, str(used.Rows[row]), re.I)
                            if(mobj):
                                for i in range(used.Columns.Count):
                                    value = str(sheet.Cells(row+1,i+1).Value)
                                    if(value.strip()):
                                        headers.append(value.strip())
                                    else:
                                        headers.append(None)
                                break
                        if(not headers):
                            print('Sheet: "{0}" has no data in "{1}"'.format(sheetname,excelfile))
                            excel.Quit()
                            os._exit(1)
                        else:
                            colcount = 0
                            flag = 0
                            if(isinstance(columns, int)):
                                if(columns < len(headers)):
                                    flag = 1
                            elif(isinstance(columns,str)):
                                nthobj = re.search(r'\s*([0-9]+)\s*[\-_=\+,#]+\s*([0-9]+)\s*', columns)
                                if(nthobj):
                                    print("boundaries are present:",nthobj.group(1),nthobj.group(2))
                                    begin_column = int(nthobj.group(1))
                                    ending_column = int(nthobj.group(2))
                                    if(begin_column > ending_column):
                                        flag = 0
                                    else:
                                        flag = 2
                            for row in range(headercount, used.Rows.Count):
                                tempdict = {}
                                res = re.sub(r'\s*','',str(used.Rows[row]))
                                skiprowobj = re.search(r'^[\(\)None\'u,\)]+$',res)
                                if(not skiprowobj):
                                    if(flag == 0):
                                        tempdict = self._ExcelWin32_build_row_dict(0, len(headers), headers, sheet, row)
                                    elif(flag == 1):
                                        tempdict = self._ExcelWin32_build_row_dict(0, columns, headers, sheet, row)
                                    elif(flag == 2):
                                        if(begin_column <= len(headers) and ending_column >= begin_column):
                                            tempdict = self._ExcelWin32_build_row_dict(begin_column-1, ending_column, headers, sheet, row)
                                    if(tempdict):
                                        finaldata.append(tempdict)
                            if(result is True or result == 'True'): #here an already unsaved excel is running
                                book.Close(True) #saving out excel without altering opened excel
                            else:
                                excel.Quit()

                    if(finaldata):
                        #print("Using Win32Com.Client Module:...List of dictionary of given data: ",finaldata,"\n\n"
                        self.datalist = finaldata
                        return finaldata
        else:
            print(excelfile+ " Excel File path does not exists")
            os._exit(1)
        
    def _ExcelWin32_build_row_dict(self, beginloop, endloop, headers, sheet, row):
        '''
        REQURIES:
        Input beginlooop: type int
        endloop: type int
        headers: type list
        sheet: type excel sheet type object
        row: type string for perticular row of excel sheet
        
        PROMISE:
        to return dictionary of current row
        Output: dict
        '''
        
        tempdict = {}
        for col in range(beginloop, endloop):
            #print("row: {0} , col: {1} , value: {2} COUNT: {3}".format(row+1,col+1,sheet.Cells(row+1,col+1).Value,used.Columns.Count)
            if(headers[col] == "None" or headers[col] is None or headers[col] == ''):
                next
            else:
                cellvalue = str(sheet.Cells(row+1,col+1).Value)
                if(cellvalue.strip() == 'None' or cellvalue.strip() == '' or cellvalue.strip() is None):
                    tempdict[headers[col]] = None
                else:
                    tempdict[headers[col]] = cellvalue.strip()
        if(tempdict):
            return tempdict
    
    def readExcelWin32Columns(self, excelfile, sheetname = "Sheet1", searchstring = '[a-zA-Z]{5,}', columns = 'All'):
        '''
        REQUIRES:
        
        Input: excelfile string type path to excel to be passed
        sheetname: string type which sheet in excel to be opened
        searchstring: type string where data header begins
        columns: type string reads range
        
        PROMISE:
        
        Method used to open and read excel file and builds dictionary of headers and values (win32com.client module is required)
        NOTE: Script is dynamic finds which row data begins and builds dict once row exists (first data existing row considered as headers)
        Returns: dict
        '''
        if(os.path.exists(excelfile)):
            try:
                result = self.check_process_status(application = 'excel.exe')
                print("excel running status;",result)
                excel = win32com.client.Dispatch("Excel.Application")
            except:
                print("Unable to open Excel application, Check if the application is installed and working fine.")
                os._exit(1)
            else:
                try:
                    abspath = os.path.abspath(excelfile)
                    book = excel.Workbooks.Open(abspath)
                    if(sheetname == "Sheet1"):
                        sheetname = book.ActiveSheet.name
                except:
                    print("Excel file is already opened please close then run the script!")
                    os._exit(1)
                else:
                    finaldata = []
                    excel.Visible = True
                    try:
                        sheet = book.Sheets(sheetname)
                    except:
                        print('"{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                        excel.Quit() 
                        return
                    else:
                        excel.DisplayAlerts = True
                        used = sheet.UsedRange
                        headercount = 0
                        headers = []
                        flag = 0
                        for row in range(used.Rows.Count):
                            headercount += 1
                            mobj = re.search(searchstring, str(used.Rows[row]), re.I)
                            if(mobj):
                                for i in range(used.Columns.Count):
                                    value = str(sheet.Cells(row+1,i+1).Value)
                                    if(value.strip()):
                                        headers.append(value.strip())
                                    else:
                                        headers.append(None)
                                break
                        if(not headers):
                            print('Sheet: "{0}" has no data in "{1}"'.format(sheetname,excelfile))
                            excel.Quit()
                            os._exit(1)
                        else:
                            colcount = 0
                            flag = 0
                            if(isinstance(columns, int)):
                                if(columns < len(headers)):
                                    flag = 1
                            elif(isinstance(columns, str)):
                                nthobj = re.search(r'\s*([0-9]+)\s*[\-_=\+,#]*\s*([0-9]+)\s*', columns)
                                if(nthobj):
                                    print("boundaries are present:",nthobj.group(1),nthobj.group(2))
                                    begin_column = int(nthobj.group(1))
                                    ending_column = int(nthobj.group(2))
                                    if(begin_column > ending_column):
                                        flag = 0
                                    else:
                                        flag = 2
                            for row in range(headercount, used.Rows.Count):
                                tempdict = {}
                                res = re.sub(r'\s*','',str(used.Rows[row]))
                                skiprowobj = re.search(r'^[\(\)None\'u,\)]+$',res)
                                if(not skiprowobj):
                                    if(flag == 0):
                                        tempdict = self._ExcelWin32_build_column_list(0, len(headers), headers, sheet, row)
                                    elif(flag == 1):
                                        tempdict = self._ExcelWin32_build_column_list(0, columns, headers, sheet, row)
                                    elif(flag == 2):
                                        if(begin_column <= len(headers) and ending_column >= begin_column):
                                            tempdict = self._ExcelWin32_build_column_list(begin_column-1, ending_column, headers, sheet, row)
                                    if(tempdict):
                                        finaldata.append(tempdict)
                            if(result is True or result == 'True'): #here an already unsaved excel is running
                                book.Close(True) #saving out excel without altering opened excel
                            else:
                                excel.Quit()

                    if(finaldata):
                        #print("Using Win32Com.Client Module:...List of dictionary of given data: ",finaldata,"\n\n"
                        self.datalist = finaldata
                        return finaldata
        else:
            print(excelfile+ " Excel File path does not exists")
            os._exit(1)
            
    def _ExcelWin32_build_column_list(self, beginloop, endloop, headers, sheet, row):
        '''
        REQURIES:
        Input beginlooop: type int
        endloop: type int
        headers: type list
        sheet: type excel sheet type object
        row: type string for perticular row of excel sheet
        
        PROMISE:
        to return dictionary of current row
        Output: dict
        '''
        #templist = []
        for col in range(beginloop, endloop):
            #print("row: {0} , col: {1} , value: {2} COUNT: {3}".format(row+1,col+1,sheet.Cells(row+1,col+1).Value,used.Columns.Count)
            if(headers[col] == "None" or headers[col] is None or headers[col] == ''):
                next
            else:
                cellvalue = (sheet.Cells(row+1,col+1).Value).encode('utf-8').strip()
                if(cellvalue.strip() == 'None' or cellvalue.strip() == '' or cellvalue.strip() is None):
                    #templist.append(None)
                    return None
                else:
                    return cellvalue.strip()
                    #templist.append(cellvalue.strip())
        #if(templist):
        #    return templist
        
    def check_process_status_powershell(self, application):
        '''
        REQUIRES: 
        Input: psfile which a powershell script contains code to check excel application is already running or not
        
        PRMOMISE:
        to returns the status of given application within the local machine where script is triggered
        Output: return boolean
        '''
        command = 'PowerShell -ExecutionPolicy RemoteSigned -command "& { $ProcessActive = Get-Process %s -ErrorAction SilentlyContinue;  if($ProcessActive -eq $null){return $False} else{return $True} }"'% application
        data = subprocess.Popen(command, stdout = subprocess.PIPE)
        result = data.communicate()[0].strip()
        print('Given Application "{}" already Running? : {}'.format(application, result))
        if(result == "True"): 
            return True  
        else: 
            return False
    
    def check_process_status(self, application):
        '''
        REQUIRES: 
        Input: psfile which a powershell script contains code to check excel application is already running or not
        
        PRMOMISE:
        to returns the status of given application within the local machine where script is triggered
        Output: return boolean
        '''
        command = 'TASKLIST /FI "IMAGENAME eq {}"'.format(application)
        data = subprocess.Popen(command, stdout = subprocess.PIPE)
        result = data.communicate()[0].strip()
        appobj = re.search(re.escape(application),result,re.IGNORECASE|re.MULTILINE)
        if(appobj):
            return True
        else: return False

    def readText(self,file, headerpattern = '\[[a-zA-Z0-9_\-\+\*&\^%\$#@!\~\`\'\s,"\.\\]+\]', datapattern = '^.*[:].*$'):
        '''
        REQUIRES:
        
        Input: file type ascii text
        headerpattern: string type contains regular expression to catch headers
        datapattern: string type contains regular expression to catch datapatterns
        
        PROMISE:
        
        Method reads textfile,configfile, logfile to parse the data and builds dict of dicts
        Returns: dict
        '''
        
        try:
            if(file and os.path.exists(file) and os.path.getsize(file) > 1):
                fin = open(file,"r") 
        except:
            print("Unable to open \"{0}\" file. Please check if the file exists or data is correct!".format(file))
            return
        else:
            countheaders = 0
            header = None
            finaldata = {} #collections.OrderedDict()
            tempdict = {} #collections.OrderedDict()
            line = fin.readline()
            while line != '':
                skiplineobj = re.search(r'^\s*#.*$',line)
                if(skiplineobj):
                    next
                else:
                    #mobj = re.search(r'\[[a-zA-Z0-9_\-\+\*&\^%$#@!\~\`\'\s*,"\.]+\]',line)
                    mobj = re.search(headerpattern,line) #searching header of pattern 
                    if(mobj):
                        countheaders += 1
                        if(tempdict):
                            finaldata.update({header:tempdict})
                            tempdict = {}
                        header = mobj.group().strip()
                    else:
                        dobj = re.search(datapattern,line) #searching data of pattern datapattern
                        if(dobj):
                            splitstring = re.search(r'\[(.*)\]',datapattern)
                            if(splitstring):
                                splitstr = splitstring.group(1).strip()
                                templist = (dobj.group().strip()).split(splitstr,1)
                            else:
                                templist = (dobj.group().strip()).split("=",1)
                            if(templist and len(templist) > 1):
                                templist[1] = re.sub( '#.*$','',templist[1].strip())
                                tempdict[templist[0].strip()] = templist[1].strip()
                            else:
                                #print("Line not maching format: yourtext = yourvalue"
                                next
                        else:
                            pass
                line = fin.readline()
            fin.close()
            if(tempdict):
                finaldata.update({header:tempdict})
            #print("total headers: {0} and FinalData: {1}".format(countheaders,finaldata)
            return finaldata

class Misc():
    def __init__(self, **kwargs):
        if(kwargs):
            self.kwargs = kwargs
        pass
    
    def trigger_threads(self,threadlist, threadlimit = 2): #here in variable threadlimit you can decide how many threads to be executed in parallel by default we have used 2.
        '''
        REQUIRES:
        
        Input: threadlist which is a customised thread class type 
        theadlimit: type integer
        
        PROMISE:
        
        This method will trigger list of threads as per thread limit, runs parallely untill list of jobs completes execution
        Returns: None
        '''
        print("$$$Thread limit to run parallely is: "+ str(threadlimit) + " $$$\n")
        joblength = len(threadlist)
        i = 0
        count = 0
        lock = threading.Lock()
        lock.acquire()
        while (True):
            if(count <= threadlimit-1):
                if(threadlist):
                    thread = threadlist.pop()
                    thread.start()
                    count = threading.active_count()
                    i += 1
                else: break
            else:
                count = threading.active_count()
                if(count <= threadlimit-1):
                    if(threadlist):
                        thread = threadlist.pop()
                        thread.start()
                        i += 1
                    else: break
                else:
                    count -= 1
            if(i==joblength+1):
                break
        lock.release()
        
    def check_application_status(self, application):
        '''
        REQUIRES: 
        Input: psfile which a powershell script contains code to check excel application is already running or not
        
        PRMOMISE:
        to returns the status of given application within the local machine where script is triggered
        Output: return boolean
        '''
        command = 'PowerShell -ExecutionPolicy RemoteSigned -command "& { $ProcessActive = Get-Process %s -ErrorAction SilentlyContinue;  if($ProcessActive -eq $null){return $False} else{return $True} }"'% application
        data = subprocess.Popen(command, stdout = subprocess.PIPE)
        result = data.communicate()[0].strip()
        print('Given Application "{}" already Running? : {}'.format(application, result))
        if(result == "True"): 
            return True  
        else: 
            return False


def main():
    '''
    main method where script begins execution
    '''
    wl = Reportlogs()
    print(wl)
    try:
        if(sys.argv and len(sys.argv) >= 1):
            fname = sys.argv[1]
            wl.writelog("file name is "+fname)
    except:
        wl.writelog("USAGE   : python <scriptname> <filename or filename with complete path>\n\t\t\tExample: python WindowsUpdate.py c:\\vmdata.xlsx")
        print("Usage   : python <" + os.path.basename(__file__) + "> <filename or filename with complete path>")
        print("Example : python "+ os.path.basename(__file__) + " "+ os.getcwd()+"\\yourfilename.xlsx")

if __name__ == "__main__":
    '''Actual block where script starts executing if triggered this script itself'''
    main()
    obj = ReadData()
    x = obj.readExcelWin32Columns("D:\\15N2_CurrentBuilds.xlsm", sheetname = "CurrentBuilds", searchstring="Asset", columns='2-2')
    pprint(x)
    #print("EXITING MAIN..."
else:
    print("***library module is successfully imported***")
