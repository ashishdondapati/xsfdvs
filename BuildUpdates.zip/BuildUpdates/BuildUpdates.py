#!C:\Python27


#####################################################
#
# BuildUpdates.py
#
# Copyright 2015 Hewlett-Packard Development Company.
#
# Hewlett-Packard and the Hewlett-Packard logo are trademarks of
# Hewlett-Packard Development Company, in the U.S. and/or other countries.
#
# Confidential computer software. Valid license from Hewlett-Packard required
# for possession, use or copying. 
#       
#       Creation date   : 2015/02/03
#       Last Modified   : 2015/04/28
#       Author          : Thejasvy.MV and Navya.KM
#       Project         : HP print(er Automation (Excel Build Updates)
#       Description     : This is a BuildUpdates script which fetches all the build updates mails from outlook(2010,2013,2007) inbox folder as specified 
#                         from configuration file and constructs an internal data structure and updates to specified excel sheets if asset names of given excels
#                         and script's assetname matches. This script can be scheduled on hourly or daily (24 hours) basis depending on the user's interest.
#
#       Class           : CreateBuildUpdates
#       Component       : BuildUpdates
#       Affects version : v1.0.2 and newer
#       Tested          : OK
##########################################################
import self as self

try:
    
    import os
    import re
    import pdb
    import time
    import copy
    import xlrd
    import HTML
    import urllib
    import pickle
    import datetime
    import threading
    import subprocess
    import unicode
    import collections
    import win32com.client
    from library import *
    from pprint import pprint
    from BeautifulSoup import BeautifulSoup, SoupStrainer
    
    
except ImportError as e:
    print("The current module is not installed in your machine, Error: ", e)
    exit()
    
class CreateBuildUpdates(ReadData, Reportlogs): #inheriting ReadData,Reportlogs classes from Library module
    '''
    This Class reads mail and updates excels of available build types
    '''
    
    def __init__(self, **kwargs):
        '''
        REQUIRES
        
        Input:kwargs: dictionaries of input key value pair format
        
        PROMISE
        
        This constructor class constructs dict from internal buildconfig.cfg file and provides a platform to build urls
        Output:None
        '''
        if(kwargs):
            self.kwargs = kwargs
        self.check()
        #self.totaldata=totaldata
        
    def check(self):
        '''
        REQUIRES:
        
        Input: an internal config file buildconfig.cfg
        
        PROMISE:
        
        to construct config dictionary to make build extraction easy mapping
        Output: Constructs Config Dictionary if config file exists
        '''
        self.FIRMWARES = 'FIRMWARES'
        #self.firmware = 'Firmware'
        self.SOFTWARES = 'SOFTWARES'
        self.WJA = 'WJA'
        self.UPD = 'UPD'
        self.DSS = 'DSS'
        self.JAC = 'JAC'
        self.MAC = 'MAC'
        self.LOCKSMITH = 'LOCKSMITH'
        self.SHAREPOINT = 'SHAREPOINT'
        self.URL = 'URL'
        self.DOCFOLDER = 'DOCFOLDER'
        self.USERNAME = 'USERNAME'
        self.PASSWORD = 'PASSWORD'
        self.TARGETFILE = "Printer_Automation.docx"
        self.EXCELDIR = "excel_builds"
        self.CONFIGFILE = "Buildconfig.cfg"   #THIS IS A STANDARD INTERNAL REFERENCE CONFIG FILE
        self.PICKLEOBJ = "pickleobj.pkl"
        self.NORMAL = 'NORMAL'
        self.OTHERBUILDS = 'OTHERBUILDS'
        self.WORKFLOW = 'WF'
        self.LEGACY = 'LEGACY'
        self.DISCRETE = 'DISCRETE'
        self.DOWNLOADFLAG = False
        
        Reportlogs.__init__(self,dirname = "BuildUpdatelogs", filename = "buildlog")
        
        
        self.FINALBUILDS = {}
        self.master_dict = {}
        self.excellist = [] #["14P4_CurrentBuilds","15P2_CurrentBuilds","15N2_CurrentBuilds","15R2_CurrentBuilds","14N3_CurrentBuilds"]
        
        self.scriptpath, self.scriptname = os.path.split(os.path.abspath(__file__))
        self.excelflag = None
        if(os.path.exists(self.scriptpath+'\\'+self.CONFIGFILE) and os.path.getsize(self.scriptpath+'\\'+self.CONFIGFILE) > 50):
            self.writelog(self.CONFIGFILE +" Present in the Script path")
            self.configdict = self.readText(file = self.scriptpath+'\\'+self.CONFIGFILE, headerpattern = '^\s*[A-Z]+\s*$', datapattern = '^.*[=].*$')
            print( "_____________CONFIGURATION FILE CONTENTS:__________________________________")
            fout = open(self.logfile,"a+")
            pprint(self.configdict, stream = fout)
            fout.close()
            pprint(self.configdict)
            print( "___________________________________________________________________________")
            self.powershell = ("C:\\Windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe")
            self.psscript = "SharePointAccess.ps1"
            self.excellist = self.do_request_sharepoint(event = "list")
            #self.excellist = ['14N1_CurrentBuilds.xlsm', '14N2_CurrentBuilds.xlsm', '14N3_CurrentBuilds.xlsm', '14P4_CurrentBuilds.xlsm', '15R1_CurrentBuilds.xlsm', '15P2_CurrentBuilds.xlsm', '15N2_CurrentBuilds.xlsm', '15R3_CurrentBuilds.xlsm', '15N4_CurrentBuilds.xlsm', '15P4_CurrentBuilds.xlsm', '1603_CurrentBuilds.xlsm']
            #self.excellist = ["14P4_CurrentBuilds.xlsm","15P2_CurrentBuilds.xlsm","15R1_CurrentBuilds.xlsm","15N2_CurrentBuilds.xlsm","14N1_CurrentBuilds.xlsm","14N2_CurrentBuilds.xlsm","14N3_CurrentBuilds.xlsm","14N4_CurrentBuilds.xlsm","15R3_CurrentBuilds.xlsm","15N4_CurrentBuilds.xlsm"]
            print( "EXCEL FILE LIST FROM SHARE POINT: ",self.excellist)
            if(len(self.excellist) == 0):
                self.writelog("Error: SharePoint connectivity Issue. Cannot proceed with BuildUpdate.")
                print( "Error: Sharepoint connectivity Issue. Cannot proceed with BuildUpdate.")
                self.send_mails(self.configdict['COMMON']["ISSUE_RECIPIENTS"], message="Error: SharePoint connectivity Issue. Cannot proceed with BuildUpdate.",attachment=self.logfile)
                os._exit(1)
            self.writelog("Successfully built config data structure.\nexcellist present")

        else:
            self.writelog("Error: An internal Config file \"{}\" does not exist!\nPlease keep the configuration file in the existing script path.".format(self.CONFIGFILE))
            print( "Error: An internal Config file \"{}\" does not exist!\nPlease keep the configuration file in the existing script path.".format(self.CONFIGFILE))
            os._exit(1)
            
    def do_request_sharepoint(self, event, filename = None):
        '''
        REQUIRES:
        
        Input: event type string contains actions like list,download,upload
        file: type string contains excel file name to be uploaded or downloaded
        
        PROMISE:
        to get list of files retrieved from share point or downloading, uploading of specific file to sharepoint
        Output: return Boolean
        '''
        pat=r'Connection Failure'
        message="SharePoint Server '{}' is Down.Check the Network connectivity".format(self.configdict[self.SHAREPOINT][self.URL])
        if (event == "list"):
            command=self.powershell,'-InputFormat',' None', '-ExecutionPolicy', 'Remotesigned', self.scriptpath+"\\"+self.psscript,"-SPUrl \""+self.configdict[self.SHAREPOINT][self.URL]+"\"", " -docfolder \""+self.configdict[self.SHAREPOINT][self.DOCFOLDER]+"\"",  "-flag '"+event+"'", "-User '"+self.configdict[self.SHAREPOINT][self.USERNAME]+"'", "-Password  '"+self.configdict[self.SHAREPOINT][self.PASSWORD]+"'","-logfile '"+self.logfile+"'"
            result = subprocess.Popen(command,stdout=subprocess.PIPE)
            outputlines=result.communicate()
            match=re.search(pat,str(outputlines[0]),re.IGNORECASE)
            if match:
                print( "SharePoint Server is Down")
                self.send_mails(self.configdict['COMMON']["RECIPIENTID"],message,attachment=self.logfile)
                os._exit(1)
            else:
                print( "SharePoint Server is fine")
                data=[x.strip() for x in str(outputlines[0]).split(',') if x.strip()]
                for item in data:
                    if(item.endswith('.xlsm')):
                        self.excellist.append(item.strip())
                if(self.excellist):
                    print( "Final Excel List:", self.excellist)
                    self.writelog("excel file list is present in sharepoint") 
            return self.excellist
        elif(event == "upload" or event == "download"):  #TO DOWNLOAD AND UPLOADING THE GIVEN MACRO ENABLED EXCEL FILE
            command = self.powershell,' -InputFormat',' None', ' -ExecutionPolicy', 'Remotesigned', self.scriptpath+"\\"+self.psscript,"-SPUrl \""+self.configdict[self.SHAREPOINT][self.URL]+"\"", " -docfolder \""+self.configdict[self.SHAREPOINT][self.DOCFOLDER]+"\"", "-TargetFolder  "+self.scriptpath+"\\excel_builds","-flag '"+event+"'"," -TargetFile  '"+filename+"'", " -User '"+self.configdict[self.SHAREPOINT][self.USERNAME]+"'", " -Password  '"+self.configdict[self.SHAREPOINT][self.PASSWORD]+"'","-logfile '"+self.logfile+"'"
            result = subprocess.Popen(command,stdout=subprocess.PIPE)
            outputlines=result.communicate()
            match=re.search(pat,str(outputlines[0]),re.IGNORECASE)
            if match:
                print( "SharePoint Server is Down")
                self.send_mails(self.configdict['COMMON']["RECIPIENTID"],message,attachment=self.logfile)
                os._exit(1)
            else:
                if(result):
                    flagobj = re.search(r'True', str(outputlines[0]), re.IGNORECASE|re.MULTILINE)
                    if(flagobj):
                        return True
                    else:
                        return False
    
    def read_mails(self, hourgap = 24):
        '''
        REQUIRES:
        
        Input: Configured outlook mail box
        Configdict built internally from constructor
        
        PROMISE:
        
        Reads outlook mail inbox folder and extracts the required build update links and returns dictionary of list
        Returns: List of Subject lines
        '''
        try:
            outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
            if(self.configdict["COMMON"].has_key("OUTLOOKMAILID")):
                try:
                    messages = outlook.Folders(self.configdict['COMMON']["OUTLOOKMAILID"]).Folders("Inbox").Items
                except:
                    messages = outlook.GetDefaultFolder(6).Items
            else:
                messages = outlook.GetDefaultFolder(6).Items     ##CONSIDERING DEFAULT INBOX FOLDER
            messages.Sort("[ReceivedTime]",True)
            message = messages.GetFirst()
        except:
            print( "This is read_email function")
            self.writelog("Unable to open outlook or outlook not configured!")
            print( "Unable to open outlook or outlook not configured!")
            os._exit(1)
        hourgap = re.sub(r'\s*[a-zA-Z_.]+$','',self.configdict['COMMON']['MAILREADLIMIT'])
        self.writelog("coming inside read Mails ({} Hours) from Now...".format(hourgap))
        print( "coming inside read Mails ({} Hours) from Now...".format(hourgap))
        self.writelog("Outlook opened successfully.")
        currentdate = datetime.datetime.today()
        gap = datetime.timedelta(hours = int(hourgap))
        mail_objlist = []
        while message:  #while loop to read  mail one by one untill mail messages are present
            #print "THIS IS MAIL TIMESTAMP FROM OUTLOOK:",message.creationtime,message.subject,type(message.subject)
            creationtime = datetime.datetime.strptime(str(message.creationtime), '%m/%d/%y %H:%M:%S')
            diffTime = currentdate - creationtime
            if(diffTime <= gap):
                if(self.is_buildmail(message) is True):
                    mail_objlist.append(message)
            elif(diffTime > gap):
                break
            message = messages.GetNext()    #this picks the next mail in inbox (from newest to oldest in order)
        if(mail_objlist):
            self.writelog("this is the unique raw message list collected from outlook on Daily basis(24 Hours):\n {}".format(mail_objlist))
            #===================================================================
            # for item in mail_objlist:
            #     print( 'SUBJECT: {},    RECEIVED TIME: {},   CREATION TIEM: {}'.format(item.subject,item.ReceivedTime,item.creationtime)
            #===================================================================
            
            return mail_objlist
        
    def is_buildmail(self, mailobj):
        '''
        REQUIRES:
        
        Input: mailobj which is a mail message object
        
        PROMISE:
        
        Method finds whether the message object is a build mail or not
        Returns: Boolean (True or False)
        '''
        if(self.configdict.has_key('SUBJECTNAMES')):
            for key in self.configdict['SUBJECTNAMES'].keys():
                mobj = re.search(re.escape(self.configdict['SUBJECTNAMES'][key]), mailobj.subject, re.IGNORECASE)
                if(mobj):
                    excludeobj=re.search(re.escape(self.configdict['EXCLUDEMAIL']['EXCLUDESUBJECT']),mailobj.subject,re.IGNORECASE)
                    if excludeobj:
                        return False
                    return True
            else: return False
    
    def extract_url(self, maillist):
        '''
        REQUIRES:
        
        Input: maillist - input type List contains list of all filtered subject lines collected from outlook mail inbox
        Configured Outlook Mail box with email id
        PROMISE:
        
        Reads outlook mail inbox folder and extracts the required build update links and returns dictionary of list of links
        Output: dictionary of object instance
        '''
        count = 0
        if(maillist is not None):
            for mailobj in maillist:  #Getting eachm mail in loop
                if(isinstance(mailobj.subject, unicode)):
                    subject =  mailobj.subject.encode('ascii','ignore')
                    self.writelog("$THIS IS MY MAIL SUBJECT LINE$: "+subject)
                self.writelog("THIS IS MY MAIL SUBJECT LINE NUMBER:{}) : {}" .format(count,subject))
                count += 1
                excel_type = ''   #when no cycle type present in mail
                build_type = ''
                build_date = ''
                multiple_cycleflag = False
                    
                for product_type in self.configdict['SUBJECTNAMES'].keys(): #getting each product_type  ex: SOFTWARES, FIRMWARES
                    print( "this is product type",product_type,mailobj.subject)
                    buildserver_obj = re.search(r'\s*\b'+re.escape(self.configdict['SUBJECTNAMES'][product_type])+r'\b', mailobj.subject, re.IGNORECASE)
                    if(buildserver_obj):
                        buildserver = self.configdict['SUBJECTNAMES'][product_type]
                        self.writelog("This is the build name found in mail subject line: " + buildserver)
                        build_date = self.get_build_date(mailobj)
                        excel_type = self.get_excel_type(mailobj, self.configdict['COMMON']['CURRENTCYCLE'])
                        print( "EXCEL_TYPE: ", excel_type,type(excel_type),mailobj.subject)
                        build_type = self.get_build_type(mailobj)
                        if(os.path.exists(self.scriptpath +"\\"+ self.PICKLEOBJ)):
                            pickle_result = self.check_pickle_old_or_new(self.scriptpath +"\\"+ self.PICKLEOBJ)
                            #pickle_result=False
                            if(pickle_result): #pickle_result is true if the pickle data object file is older than MAILREADLIMIT
                                self.writelog("Pickle file is very Older than given time limit.Creating New Master Dictionary")
                                self.master_dict = self.build_master_dict(self.excellist)
                                if(self.master_dict):
                                    self.DOWNLOADFLAG = True
                                    self.pickle_dump(self.scriptpath +"\\"+ self.PICKLEOBJ, self.master_dict)
                            else:
                                self.master_dict = self.pickle_load(self.scriptpath +"\\"+ self.PICKLEOBJ)
                                
                        else:
                            #print "pickle file not found"
                            self.writelog("pickle file not found.Creating New Master Dict")
                            self.master_dict = self.build_master_dict(self.excellist)
                            if(self.master_dict):
                                #print "sel...........:",self.master_dict
                                self.DOWNLOADFLAG = True
                                self.pickle_dump(self.scriptpath +"\\"+ self.PICKLEOBJ, self.master_dict)                        
                    
                        if(product_type == self.UPD):
                            self.writelog("calling builds: " + self.UPD)
                            
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                if(self.master_dict.has_key(excel_type)):
                                    if(self.master_dict[excel_type].has_key(self.UPD)):
                                        self.build_url(mailobj, product_type,excel_type, build_type, self.master_dict[excel_type][self.UPD], build_date)
                                    else:
                                        #print self.UPD, " Not present inside excel_type: ",excel_type
                                        self.writelog(self.UPD+' is not present inside excel_ type "'+excel_type+'"')
                                else:
                                    #print excel_type," Not present"
                                    self.writelog(excel_type+' is not present')
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                i=1
                                for xtype in excel_type:
                                    #print i,"I am Here in Software",xtype
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.UPD)):
                                            self.build_url(mailobj, product_type,xtype, build_type, self.master_dict[xtype][self.UPD], build_date)
                                        else:
                                            #print self.UPD, " Not present inside excel_type: ",xtype
                                            self.writelog(self.UPD+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        self.writelog(xtype+' is not present')
    
                        elif(product_type == self.WJA):
                            self.writelog("calling builds: " + self.WJA)
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                if(self.master_dict.has_key(excel_type)):
                                    if(self.master_dict[excel_type].has_key(self.WJA)):
                                        self.build_url(mailobj, product_type,excel_type, build_type, self.master_dict[excel_type][self.WJA], build_date)
                                    else:
                                        #print self.WJA, " Not present inside excel_type: ",excel_type
                                        self.writelog(self.WJA+' is not present inside excel_ type "'+excel_type+'"')
                                else:
                                    #print excel_type," Not present"
                                    self.writelog(excel_type+' is not present')
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                i=1
                                #print "Multiple excel sheets are to be updated"
                                for xtype in excel_type:
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.WJA)):
                                            self.build_url(mailobj, product_type,xtype, build_type, self.master_dict[xtype][self.WJA], build_date)
                                        else:
                                            #print self.WJA, " Not present inside excel_type: ",xtype
                                            self.writelog(self.WJA+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        #print xtype," Not present"
                                        self.writelog(xtype+' is not present')
                                
                        elif(product_type == self.DSS):
                            self.writelog("calling builds: " + self.DSS)
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                if(self.master_dict.has_key(excel_type)):
                                    if(self.master_dict[excel_type].has_key(self.DSS)):
                                        self.build_url(mailobj, product_type,excel_type, build_type, self.master_dict[excel_type][self.DSS], build_date)
                                    else:
                                        #print self.DSS, " Not present inside excel_type: ",excel_type
                                        self.writelog(self.DSS+' is not present inside excel_ type "'+excel_type+'"')
                                else:
                                    #print excel_type," Not present"
                                    self.writelog(excel_type+' is not present')
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                i=1
                                #print "Multiple excel sheets are to be updated"
                                for xtype in excel_type:
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.DSS)):
                                            self.build_url(mailobj, product_type,xtype, build_type, self.master_dict[xtype][self.DSS], build_date)
                                        else:
                                            print( self.DSS, " Not present inside excel_type: ",xtype)
                                            self.writelog(self.DSS+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        print( xtype," Not present")
                                        self.writelog(xtype+' is not present')
                                
                        elif(product_type == self.JAC):
                            self.writelog("calling builds: " + self.JAC)
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                if(self.master_dict.has_key(excel_type)):
                                    if(self.master_dict[excel_type].has_key(self.JAC)):
                                        self.build_url(mailobj, product_type,excel_type, build_type, self.master_dict[excel_type][self.JAC], build_date)
                                    else:
                                        #print self.JAC, " Not present inside excel_type: ",excel_type
                                        self.writelog(self.JAC+' is not present inside excel_ type "'+excel_type+'"')
                                else:
                                    #print excel_type," Not present"
                                    self.writelog(excel_type+' is not present')
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                i=1
                                #print "Multiple excel sheets are to be updated"
                                for xtype in excel_type:
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.JAC)):
                                            print( "sheet to be passed",xtype,type(xtype))
                                            self.build_url(mailobj, product_type,xtype, build_type, self.master_dict[xtype][self.JAC], build_date)
                                        else:
                                            print( self.JAC, " Not present inside excel_type: ",xtype)
                                            self.writelog(self.JAC+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        #print xtype," Not present"
                                        self.writelog(xtype+' is not present')
                        
                        elif(product_type == self.LOCKSMITH):
                            self.writelog("calling builds: " + self.LOCKSMITH)
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                
                                if(self.master_dict.has_key(excel_type)):
                                    if(self.master_dict[excel_type].has_key(self.LOCKSMITH)):
                                        self.build_url(mailobj, product_type,excel_type, build_type, self.master_dict[excel_type][self.LOCKSMITH], build_date)
                                    else:
                                        #print self.LOCKSMITH, " Not present inside excel_type: ",excel_type
                                        self.writelog(self.LOCKSMITH+' is not present inside excel_ type "'+excel_type+'"')
                                else:
                                    print( excel_type," Not present")
                                    self.writelog(excel_type+' is not present')
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                i=1
                                #print "Multiple excel sheets are to be updated"
                                for xtype in excel_type:
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.LOCKSMITH)):
                                            self.build_url(mailobj, product_type,xtype, build_type, self.master_dict[xtype][self.LOCKSMITH], build_date)
                                        else:
                                            #print self.LOCKSMITH, " Not present inside excel_type: ",xtype
                                            self.writelog(self.LOCKSMITH+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        #print xtype," Not present"
                                        self.writelog(xtype+' is not present')
                                        
                        #NAVYA : NEW CODE UPDATED FOR MAC                
                        elif(product_type == self.MAC):
                            self.writelog("calling builds: " + self.MAC)
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                if(self.master_dict.has_key(excel_type)):
                                    if(self.master_dict[excel_type].has_key(self.MAC)):
                                        self.build_url(mailobj, product_type,excel_type, build_type, self.master_dict[excel_type][self.MAC], build_date)
                                    else:
                                        #print self.WJA, " Not present inside excel_type: ",excel_type
                                        self.writelog(self.MAC+' is not present inside excel_ type "'+excel_type+'"')
                                else:
                                    #print excel_type," Not present"
                                    self.writelog(excel_type+' is not present')
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                i=1
                                #print "Multiple excel sheets are to be updated"
                                for xtype in excel_type:
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.MAC)):
                                            self.build_url(mailobj, product_type,xtype, build_type, self.master_dict[xtype][self.MAC], build_date)
                                        else:
                                            #print self.WJA, " Not present inside excel_type: ",xtype
                                            self.writelog(self.MAC+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        #print xtype," Not present"
                                        self.writelog(xtype+' is not present')
            
                        elif(product_type == self.FIRMWARES):
                            print( "COMING INSIDE FIRMWARESSSSSSS: ", product_type)
                            self.writelog("calling {} builds: " + self.FIRMWARES)
                            #print "coming inside firmwares......",self.master_dict[excel_type][self.FIRMWARES]
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                if(self.master_dict.has_key(excel_type)):
                                    print( "HERE IS EXCEL_TYPE")
                                    if(self.master_dict[excel_type].has_key(self.FIRMWARES)):
                                        self.build_firmware_url(mailobj, excel_type, build_type, self.master_dict[excel_type][self.FIRMWARES], build_date)
                                    else:
                                        #print self.FIRMWARES, " Not present inside excel_type: ",self.excel_type
                                        self.writelog(self.FIRMWARES+' is not present inside excel_ type "'+excel_type+'"')
                                else:
                                    #print excel_type," Not present"
                                    self.writelog(excel_type+' is not present')
                                    
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                #print "Multiple excel sheets are to be updated"
                                for xtype in excel_type:
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.FIRMWARES)):
                                            self.build_firmware_url(mailobj, xtype, build_type, self.master_dict[xtype][self.FIRMWARES],build_date)
                                        else:
                                            #print self.FIRMWARES, " Not present inside excel_type: ",xtype
                                            self.writelog(self.FIRMWARES+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        #print xtype," Not present"
                                        self.writelog(xtype+' is not present')
            
                        elif(product_type == self.SOFTWARES):
                            self.writelog("calling {} builds :" + self.SOFTWARES)
                            #print "coming inside softwaressssss"
                            if isinstance(excel_type,str) or isinstance(excel_type,unicode):
                                if(self.master_dict.has_key(excel_type)):
                                    if(self.master_dict[excel_type].has_key(self.SOFTWARES)):
                                        self.build_software_url(mailobj,excel_type,build_type,self.master_dict[excel_type][self.SOFTWARES],build_date)
                                    else:
                                        #print self.SOFTWARES, " Not present inside excel_type: ",excel_type
                                        self.writelog(self.SOFTWARES+' is not present inside excel_type "'+excel_type+'"')
                                else:
                                        #print excel_type," Not present"
                                        self.writelog(excel_type+' is not present')
                            else:
                                self.writelog("Multiple excel sheets are to be updated ")
                                #print "Multiple excel sheets are to be updated"
                                for xtype in excel_type:
                                    if(self.master_dict.has_key(xtype)):
                                        if(self.master_dict[xtype].has_key(self.SOFTWARES)):
                                            self.build_software_url(mailobj,xtype,build_type,self.master_dict[xtype][self.SOFTWARES],build_date)
                                        else:
                                            #print self.SOFTWARES, " Not present inside excel_type: ",xtype
                                            self.writelog(self.SOFTWARES+' is not present inside excel_ type "'+xtype+'"')
                                    else:
                                        #print xtype,"Not present"
                                        self.writelog(xtype+' is not present')
                        else:
                            print( "THERE IS NO BUILD URLSSSSSS TO PROCESS")
                                
                        break#breaking for product_type in self.configdict['SUBJECTNAMES'].keys(): ->loop                               
            if(self.FINALBUILDS.values()):
                #self.writelog('='*20)
                return self.FINALBUILDS
            else:
                print( "*"*200+"NO BUILDSSSSSSSSSSSSSSS"+"*" *200)
            
    def get_build_date(self, mailobj):
        '''
        
        '''
        date_month_pat = r'\b((0?[1-9])|(1[0-2]))[/\-]((0?[1-9])|([1-2][0-9])|(3[0-1]))([/\-]\d{2,4})?\b'
        currentyear = datetime.date.today().year
        dateobj = re.search(date_month_pat, mailobj.subject)
        if(dateobj):
            #print "this is raw date found in mail subject line: ",dateobj.group(0)
            tempdate = dateobj.group(0).replace('-','/')
            build_date = tempdate + "/" + str(currentyear)
            build_date = datetime.datetime.strptime(build_date,'%m/%d/%Y').strftime("%x 00:00:00")
            #print "BUILD DATE IS FOUND IN MAIL SUBEJCT LINE:" + build_date, type(build_date)
            self.writelog("BUILD DATE IS FOUND IN MAIL SUBEJCT LINE (FORMATTED): " + build_date)
        else:
            currentdate = datetime.datetime.now().date().strftime('%m/%d/%Y')
            build_date = datetime.datetime.strptime(currentdate,'%m/%d/%Y').strftime("%x 00:00:00")
            self.writelog("BUILD DATE IS NOT FOUND IN MAIL SUBEJCT LINE, CONSIDERING CURRENT DATE: " + build_date)
            #print "BUILD DATE IS NOT FOUND IN MAIL SUBEJCT LINE, CONSIDERING CURRENT DATE: ", build_date, type(build_date)
        return build_date
    
    def get_excel_type(self, mailobj, currentcycle):
        #pattern=r'(\d+[a-zA-Z]?\d+)[\\\\-]?'
        #navya:add new code for 16.03
        #pattern=r'(\d+[a-zA-Z]?\d+)[\\\\-]?'
        pattern = r'(\b\[?\d+[a-zA-Z\.\,]?\d+\]?\b)[\\\\-]?'
        #pattern = r'(\b\[?\d+[a-zA-Z\.\,]\d+\]?\b)[\\\\-]?'
        #pattern = r'\[([^]]*)\]'
        exlmatchobj = re.findall(pattern, mailobj.subject,re.I)
        
        #exlmatchobj = re.search(r'\b[0-9]+[A-Z]+[0-9]+', mailobj.subject)
        excel_type = None
        if(exlmatchobj):
            print( "EXCEL MATCH FOUND")
            build_cycle = exlmatchobj
            #build_cycle = exlmatchobj.group(0)
            #excel_type = exlmatchobj.group()
            #print "BUILD_CYCLE", excel_type
            if len(build_cycle) == 1:
                print( "SINGLE BUILD CYCLE",build_cycle)
                #excel_type=build_cycle[0].replace('.','')
                excel_type=build_cycle
                excel_type=str(excel_type)
            else:
                print( "IT IS MULTIPLE BUILD CYCLE",build_cycle)
                excel_type=build_cycle
            print( "IT HAS BUILD_CYCLE", excel_type,type(excel_type))
            self.writelog("SUBJECT LINE HAS BUILD CYCLE" + str(excel_type))
        else:
            multiple_cycleobj = re.search(r',', currentcycle)
            if(multiple_cycleobj):
                multiple_cycleflag = True
                multiple_cycle = self.configdict['COMMON']['CURRENTCYCLE'].split(',')
                excel_type = multiple_cycle
                print( "SUBJECT LINE HAS NO BUILD CYCLE, CONSIDERING MULTIPLE CURRENT CYCLES AS GIVEN IN BILDCONFIG FILE: ", excel_type)
                self.writelog("SUBJECT LINE HAS NO BUILD CYCLE, CONSIDERING MULTIPLE CURRENT CYCLES AS GIVEN IN BILDCONFIG FILE: " + str(excel_type))
            else:
                excel_type = self.configdict['COMMON']['CURRENTCYCLE']
                self.writelog("SUBJECT LINE HAS NO BUILD CYCLE, CONSIDERING CURRENT CYCLE AS GIVEN IN BUILDCONFIG FILE: " + excel_type)
                print( "SUBJECT LINE HAS NO BUILD CYCLE, CONSIDERING CURRENT CYCLE AS GIVEN IN BUILDCONFIG FILE: " + excel_type)
        return excel_type
    
    def get_build_type(self, mailobj):
        buildtypeobj = re.search(r'^.*(([RF]C|[BM]R)([0-9]+)?).*$',mailobj.subject)
        if(buildtypeobj):
            return buildtypeobj.group(1)
    
    def get_master_dict(self):
        master_script = self.scriptpath+ "\\BuildMasterList.py"
        #print master_script, 'master script path.....'
        if(os.path.exists(master_script)):
            subprocess.Popen('python '+ master_script)
            #result = subprocess.Popen(master_script, stdout=subprocess.PIPE)
            #result = result.communicate()[0].strip()
            result = os.popen('python ' + master_script)
            print( "master script result.................",type(result))
            return result
        else:
            print( "master script file does not exist in script path: "+ master_script)
    
    def pickle_dump(self, pickle_file, data):
        filehandler = open(str(pickle_file), "wb")
        pickle.dump(data, filehandler)
        filehandler.close()
        
    def pickle_load(self, pickle_file):
        if(os.path.exists(pickle_file)):
            file = open(pickle_file, 'rb')
            object_file = pickle.load(file)
            #print "*" * 100
            #pprint(object_file)
            file.close()
            #print "$" * 100
            return object_file
        else:
            print( "No pickle file path present")
    
    def check_pickle_old_or_new(self, picklefile):
        if(os.path.exists(picklefile)):
            currentdate = datetime.datetime.today()
            hourgap = re.sub(r'\s*[a-zA-Z_.]+$','',self.configdict['COMMON']['MASTERLIST'])
            gap = datetime.timedelta(hours = int(hourgap))
            creationtime = datetime.datetime.strptime(time.ctime(os.path.getmtime(picklefile)), '%a %b %d %H:%M:%S %Y')
            difftime = currentdate - creationtime
            if(difftime > gap):
                print( "difference time more than gap hours", hourgap)
                flag = True
                #master_dict = self.get_master_dict()
            else:
                #print "pickle is not too old just load pickle object"
                flag = False
            return flag
        
    def read_excel_column_orig(self, excelfile,sheetname,column):
        columndata=[]
        workbook = xlrd.open_workbook(excelfile)
        count=0
        try:
            worksheet = workbook.sheet_by_name(sheetname)
        except:
                print( 'line no: 621,  "{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                return
        else:
            for row_idx in range(0, worksheet.nrows):
                if worksheet.cell(row_idx, column).value:
                    if 'Discrete' in worksheet.cell(row_idx,column).value:
                        print( worksheet.cell(row_idx,1).value)
                        count=count+1
                    columndata.append(worksheet.cell(row_idx, column).value)
            #print "Total count of software products",count
        return columndata
    
    
    def read_excel_column_dict(self, excelfile, excel_type, sheetname, column):
            print( "after read excel column dict 2 linesssssssssssss")
            try:
                workbook = xlrd.open_workbook(excelfile)
                worksheet = workbook.sheet_by_name(sheetname)
            except:
                    print( 'line no: 640 ,"{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                    return
            else:
                regex_dict = {}
                master_dict = collections.OrderedDict()
                
                if(master_dict.has_key(excel_type) is not True):
                    master_dict.update({excel_type:{}})
                
                regex_dict.update({self.SOFTWARES : r'(' + self.LEGACY + r'(\))?)?\s*(' + self.DISCRETE + r')'})
                regex_dict.update({self.FIRMWARES : r'(' + self.WORKFLOW + r'(\))?)?\s*(Firmware|FW\s*$' + r')'})
                regex_dict.update({self.WJA : re.escape(self.WJA)+r'|Web\s*Jet\s*Admin'})
                regex_dict.update({self.JAC : re.escape(self.JAC)})
                regex_dict.update({self.DSS : r'Digital\s*send\s*(SW)?.*'})
                regex_dict.update({self.UPD : r'\b'+re.escape(self.UPD)+r'|Tool(s)?'})
                regex_dict.update({self.MAC : re.escape(self.MAC)+r'\s*(OS)?\s*'})
                regex_dict.update({self.LOCKSMITH : re.escape(self.LOCKSMITH)})
                
                for row_index in range(0, worksheet.nrows):
                    assetvalue = worksheet.cell(row_index, 1).value
                    if(isinstance(assetvalue, unicode)):
                        assetvalue = unicodedata.normalize('NFKD', assetvalue).encode('ascii','ignore')
                    else: assetvalue.encode('utf-8')
                    or_obj = re.search(r'(.*)\s+(or|and)\s+.*\s+(\w+)\s*$', assetvalue, re.IGNORECASE)
                    if(or_obj):
                        #print "COMING INSIDE OR CONTIANG ASSET NAMEEEEEEEEEEEEEEEEEEEEEEE", or_obj.group(2)
                        assetvalue = or_obj.group(1).strip() + or_obj.group(3).strip()
                   
                    assetvalue = re.sub(r'\s+','',assetvalue.strip()).lower()
                    assetvalue = assetvalue.strip()
                    current_build_value = worksheet.cell(row_index, 2).value
                    #print "ROW INDEXXX:", row_index+1, assetvalue#, "CURRENT BUILD VALUE:",current_build_value
                    if assetvalue is not None or assetvalue != '':
                        regex_count = 0
                        for key_pattern in regex_dict.keys():
                            flag = False
                            pattern_match=re.search(regex_dict[key_pattern], assetvalue, re.IGNORECASE)
                            if pattern_match:
                                if key_pattern == self.MAC:
                                    if master_dict[excel_type].has_key(self.MAC) is not True:
                                        master_dict[excel_type].update({self.MAC:{}})
                                    if(master_dict[excel_type][self.MAC].has_key(self.NORMAL) is not True):
                                        master_dict[excel_type][self.MAC].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.MAC][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                                elif key_pattern == self.SOFTWARES:
                                    if master_dict[excel_type].has_key(self.SOFTWARES) is not True:
                                            master_dict[excel_type].update({self.SOFTWARES:{}})
                                    if(pattern_match.group(1)):
                                        if master_dict[excel_type][self.SOFTWARES].has_key(self.LEGACY) is not True:
                                            master_dict[excel_type][self.SOFTWARES].update({self.LEGACY:{}})
                                        master_dict[excel_type][self.SOFTWARES][self.LEGACY].update({assetvalue:row_index+1})
                                    else:
                                        if master_dict[excel_type][self.SOFTWARES].has_key(self.NORMAL) is not True:
                                                master_dict[excel_type][self.SOFTWARES].update({self.NORMAL:{}})
                                        master_dict[excel_type][self.SOFTWARES][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                                    
                                elif key_pattern == self.FIRMWARES:
                                    if master_dict[excel_type].has_key(self.FIRMWARES) is not True:
                                            master_dict[excel_type].update({self.FIRMWARES:{}})
                                    if(pattern_match.group(1)):
                                        if master_dict[excel_type][self.FIRMWARES].has_key(self.LEGACY) is not True:
                                            master_dict[excel_type][self.FIRMWARES].update({self.LEGACY:{}})
                                        master_dict[excel_type][self.FIRMWARES][self.LEGACY].update({assetvalue:row_index+1})
                                    else:
                                        if master_dict[excel_type][self.FIRMWARES].has_key(self.NORMAL) is not True:
                                                master_dict[excel_type][self.FIRMWARES].update({self.NORMAL:{}})
                                        master_dict[excel_type][self.FIRMWARES][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                                
                                elif key_pattern == self.WJA:
                                    if master_dict[excel_type].has_key(self.WJA) is not True:
                                        master_dict[excel_type].update({self.WJA:{}})
                                    if(master_dict[excel_type][self.WJA].has_key(self.NORMAL) is not True):
                                        master_dict[excel_type][self.WJA].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.WJA][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                                
                                elif key_pattern == self.UPD:
                                    if master_dict[excel_type].has_key(self.UPD) is not True:
                                        master_dict[excel_type].update({self.UPD:{}})
                                    if(master_dict[excel_type][self.UPD].has_key(self.NORMAL) is not True):
                                        master_dict[excel_type][self.UPD].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.UPD][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                                
                                elif key_pattern == self.DSS:
                                    if master_dict[excel_type].has_key(self.DSS) is not True:
                                        master_dict[excel_type].update({self.DSS:{}})
                                    if(master_dict[excel_type][self.DSS].has_key(self.NORMAL) is not True):
                                        master_dict[excel_type][self.DSS].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.DSS][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                                
                                elif key_pattern == self.JAC:
                                    if master_dict[excel_type].has_key(self.JAC) is not True:
                                        master_dict[excel_type].update({self.JAC:{}})
                                    if(master_dict[excel_type][self.JAC].has_key(self.NORMAL) is not True):
                                        master_dict[excel_type][self.JAC].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.JAC][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                                
                                elif(key_pattern == self.LOCKSMITH):
                                    if(master_dict[excel_type].has_key(self.LOCKSMITH) is not True):
                                        master_dict[excel_type].update({self.LOCKSMITH:{}})
                                    if(master_dict[excel_type][self.LOCKSMITH].has_key(self.NORMAL) is not True):
                                        master_dict[excel_type][self.LOCKSMITH].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.LOCKSMITH][self.NORMAL].update({assetvalue:row_index+1})
                                    break
                            else:
                                #print "COUNTING FOR OTHER BUILDS"
                                regex_count += 1
                            if regex_count == len(regex_dict.keys()):
                                if assetvalue != 'Asset Name' and assetvalue:
                                    if master_dict[excel_type].has_key(self.OTHERBUILDS) is not True:
                                        master_dict[excel_type].update({self.OTHERBUILDS:{}})
                                    if(master_dict[excel_type][self.OTHERBUILDS].has_key(self.NORMAL) is not True):
                                        master_dict[excel_type][self.OTHERBUILDS].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.OTHERBUILDS][self.NORMAL].update({assetvalue:row_index+1})
                return master_dict
        
    def build_master_dictionary_win32(self,excelfile, excel_type, sheetname,searchstring,column):
        if(os.path.exists(excelfile)):
            try:
                result = self.check_process_status(application = 'excel.exe')
                print( "excel running status;",result)
                excel = win32com.client.Dispatch("Excel.Application")
                runningexcel = win32com.client.GetObject (os.path.abspath(excelfile))
            except:
                    print( 'Unable to open Excel application, Check if the application is installed and working fine')
                    return False
            else:
                try:
                    print( "this is value of running excel",runningexcel,"********************")
                    excelpath = os.path.abspath(excelfile)
                    book = excel.Workbooks.Open(excelpath)
                    if(sheetname == "Sheet1"):
                        sheetname = book.ActiveSheet.name
                except:
                    print( "Excel file is already opened please close then run the script!")
                    return
                    #os._exit(1)
                else:
                    excel.Visible = True
                    try:
                        sheet = book.Sheets(sheetname)
                    except:
                        print( '"{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                        excel.Application.Quit() 
                        return
                    else:
                        regex_dict = {}
                        master_dict = collections.OrderedDict()
                        
                        if(master_dict.has_key(excel_type) is not True):
                            master_dict.update({excel_type:{}})
                        
                        regex_dict.update({self.SOFTWARES : r'(' + self.LEGACY + r'(\))?)?\s*(' + self.DISCRETE + r')'})
                        regex_dict.update({self.FIRMWARES : r'(' + self.WORKFLOW + r'(\))?)?\s*(Firmware|FW\s*$' + r')'})
                        regex_dict.update({self.WJA : re.escape(self.WJA)+r'|Web\s*Jet\s*Admin'})
                        regex_dict.update({self.JAC : re.escape(self.JAC)})
                        regex_dict.update({self.DSS : re.escape(self.DSS)+r'|Digital\s*send\s*(SW)?.*'})
                        regex_dict.update({self.UPD : r'\b'+re.escape(self.UPD)+r'|Tool(s)?'})
                        regex_dict.update({self.MAC : re.escape(self.MAC)+r'\s*(OS)?\s*'})
                        regex_dict.update({self.LOCKSMITH : re.escape(self.LOCKSMITH)})
                        
                        
                        excel.DisplayAlerts = True
                        used = sheet.UsedRange
                        headercount = 0
                        headers = []
                        flag = 0
                        for row in range(used.Rows.Count):
                                headercount += 1
                                #print "Row:::",row
                                mobj = re.search(searchstring, str(used.Rows[row]), re.I)
                                if(mobj):
                                    for i in range(used.Columns.Count):
                                        value = str(sheet.Cells(row+1,i+1).Value)
                                        if(value.strip()):
                                            headers.append(value.strip())
                                        else:
                                            headers.append(None)
                                    break
                        if(not headers):
                            print( 'Sheet: "{0}" has no data in "{1}"'.format(sheetname,excelfile))
                            excel.Quit()
                            os._exit(1)
                        else:
                            print( "This is LIST")
                            print( headers)
                            for row in range(headercount, used.Rows.Count):
                                assetvalue = sheet.Cells(row+1,column).Value
                                if(assetvalue == 'None' or assetvalue == '' or assetvalue is None):
                                    pass
                                else:
                                    if(isinstance(assetvalue, unicode)):
                                        assetvalue = unicodedata.normalize('NFKD', assetvalue).encode('ascii','ignore')
                                    else: assetvalue.encode('utf-8')
                                    or_obj = re.search(r'(.*)\s+(or|and)\s+.*\s+(\w+)\s*$', assetvalue, re.IGNORECASE)
                                    if(or_obj):
                                        #print "COMING INSIDE OR CONTIANG ASSET NAMEEEEEEEEEEEEEEEEEEEEEEE", or_obj.group(2)
                                        assetvalue = or_obj.group(1).strip() + or_obj.group(3).strip()
                                   
                                    assetvalue = re.sub(r'\s+','',assetvalue.strip()).lower()
                                    assetvalue = assetvalue.strip()
                                    current_build_value = sheet.Cells(row+1,column+1).Value
                                    #print "ROW INDEXXX:", row_index+1, assetvalue#, "CURRENT BUILD VALUE:",current_build_value
                                    if assetvalue is not None or assetvalue != '':
                                        regex_count = 0
                                        for key_pattern in regex_dict.keys():
                                            flag = False
                                            pattern_match=re.search(regex_dict[key_pattern], assetvalue, re.IGNORECASE)
                                            if pattern_match:
                                                if key_pattern == self.MAC:
                                                    if master_dict[excel_type].has_key(self.MAC) is not True:
                                                        master_dict[excel_type].update({self.MAC:{}})
                                                    if(master_dict[excel_type][self.MAC].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.MAC].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.MAC][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                elif key_pattern == self.SOFTWARES:
                                                    if master_dict[excel_type].has_key(self.SOFTWARES) is not True:
                                                            master_dict[excel_type].update({self.SOFTWARES:{}})
                                                    if(pattern_match.group(1)):
                                                        if master_dict[excel_type][self.SOFTWARES].has_key(self.LEGACY) is not True:
                                                            master_dict[excel_type][self.SOFTWARES].update({self.LEGACY:{}})
                                                        master_dict[excel_type][self.SOFTWARES][self.LEGACY].update({assetvalue:row+1})
                                                    else:
                                                        if master_dict[excel_type][self.SOFTWARES].has_key(self.NORMAL) is not True:
                                                                master_dict[excel_type][self.SOFTWARES].update({self.NORMAL:{}})
                                                        master_dict[excel_type][self.SOFTWARES][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                    
                                                elif key_pattern == self.FIRMWARES:
                                                    if master_dict[excel_type].has_key(self.FIRMWARES) is not True:
                                                            master_dict[excel_type].update({self.FIRMWARES:{}})
                                                    if(pattern_match.group(1)):
                                                        if master_dict[excel_type][self.FIRMWARES].has_key(self.LEGACY) is not True:
                                                            master_dict[excel_type][self.FIRMWARES].update({self.LEGACY:{}})
                                                        master_dict[excel_type][self.FIRMWARES][self.LEGACY].update({assetvalue:row+1})
                                                    else:
                                                        if master_dict[excel_type][self.FIRMWARES].has_key(self.NORMAL) is not True:
                                                                master_dict[excel_type][self.FIRMWARES].update({self.NORMAL:{}})
                                                        master_dict[excel_type][self.FIRMWARES][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.WJA:
                                                    if master_dict[excel_type].has_key(self.WJA) is not True:
                                                        master_dict[excel_type].update({self.WJA:{}})
                                                    if(master_dict[excel_type][self.WJA].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.WJA].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.WJA][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.UPD:
                                                    if master_dict[excel_type].has_key(self.UPD) is not True:
                                                        master_dict[excel_type].update({self.UPD:{}})
                                                    if(master_dict[excel_type][self.UPD].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.UPD].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.UPD][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.DSS:
                                                    if master_dict[excel_type].has_key(self.DSS) is not True:
                                                        master_dict[excel_type].update({self.DSS:{}})
                                                    if(master_dict[excel_type][self.DSS].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.DSS].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.DSS][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.JAC:
                                                    if master_dict[excel_type].has_key(self.JAC) is not True:
                                                        master_dict[excel_type].update({self.JAC:{}})
                                                    if(master_dict[excel_type][self.JAC].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.JAC].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.JAC][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif(key_pattern == self.LOCKSMITH):
                                                    if(master_dict[excel_type].has_key(self.LOCKSMITH) is not True):
                                                        master_dict[excel_type].update({self.LOCKSMITH:{}})
                                                    if(master_dict[excel_type][self.LOCKSMITH].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.LOCKSMITH].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.LOCKSMITH][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                            else:
                                                #print "COUNTING FOR OTHER BUILDS"
                                                regex_count += 1
                                            if regex_count == len(regex_dict.keys()):
                                                if assetvalue != 'Asset Name' and assetvalue:
                                                    if master_dict[excel_type].has_key(self.OTHERBUILDS) is not True:
                                                        master_dict[excel_type].update({self.OTHERBUILDS:{}})
                                                    if(master_dict[excel_type][self.OTHERBUILDS].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.OTHERBUILDS].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.OTHERBUILDS][self.NORMAL].update({assetvalue:row+1})
            
            book.Close(True,excelfile)
            #excel.Quit()
            print(master_dict)
            return master_dict
        else:
            print( excelfile+ " Excel File path does not exists")
            os._exit(1)
    
        
    

    def build_master_dict(self, excellist):
        master_dict = {}
        currentyear=datetime.datetime.now().year
        final_year=currentyear%100
        sheetname = "CurrentBuilds"
        column = 2
        for excel in excellist:
            #if excel.startswith(str(final_year)):
                cycle = excel.split('_')[0]
                excelfilepath = self.scriptpath + '\\' + self.EXCELDIR+'\\' + excel
                download_result = self.do_request_sharepoint(event = "download", filename = excel)
                #download_result=True
                if(download_result == True or download_result == 'True'):
                    self.writelog(excel + ' Download is Successful')
                    if(os.path.exists(excelfilepath)):
                        #print "inside masterdict ^^^^^^^: ", excelfilepath, cycle, sheetname, column
                        #master_dict.update(self.read_excel_column_dict(excelfilepath, cycle, sheetname, column))
                        master_dict.update(self.build_master_dictionary_win32(excelfilepath, cycle, sheetname, 'Asset',column))
                        #print "&&&&&&&&&&&&&"
                        #pprint(master_dict)
                        #master_dict.update()
                else:
                    print( excel + " download failed")
                    self.writelog(excel + ' Download Failed')
        if (master_dict):
            return master_dict
        else:
            return None
    
    
    def create_ifnotexist_excel_type_product_type(self,excel_type,product_type,build_date):
        '''
        REQUIRES:
        Input: excel_type  type string holds build cycle name like 15N2, 15R1 etc
        subname: type string holds product name like SOFTWARES, FIRMWARES
        
        PROMISE:
        to create an empty dictionary of required hierarchy
        Output: return None   
        '''
        if(self.FINALBUILDS.has_key(excel_type) is not True):
            self.FINALBUILDS.update({excel_type:{}})
        if(self.FINALBUILDS[excel_type].has_key(product_type) is not True):
            self.FINALBUILDS[excel_type].update({product_type:{}})
        if(self.FINALBUILDS[excel_type][product_type].has_key(build_date) is not True):
            self.FINALBUILDS[excel_type][product_type].update({build_date:{}})
        
    def build_legacy_and_new_dict(self, datalist, oldkeyword, newkeyword):
        '''
        REQUIRES:
        Input:
            datalist: type list contains mail content or excel assetname content
            oldkeyword: type string contains words Legacy or WF etc,.
            newkeyword: type string contains words Discrete or Firmware etc,.
        PROMISE:
            method loops through the datalist and matches oldkeyword and newkeyword and builds dict of lists
        Output:
            to return dict of lists
        '''
        data_assets = {}
        if(data_assets.has_key(oldkeyword) is not True):
            data_assets.update({oldkeyword:{}})
        if(data_assets.has_key(newkeyword) is not True):
            data_assets.update({newkeyword:{}})
            
        for assetname in datalist:
            mobj = re.search(r'(' + oldkeyword + r'(\))?)?\s*(' + newkeyword + r')', assetname, re.IGNORECASE)
            if mobj:
                if(mobj.group(1)):
                    data_assets[oldkeyword].update({assetname:assetname})
                else:
                    data_assets[newkeyword].update({assetname:assetname})
        if(data_assets):
            return data_assets
          

            
    def getbuild_number(self,buildnum):
        minorversion=''
        majorversion=''
        pat=r'[\._\d\-]+[^a-zA-Z]'
        buildpat=r'\b((^[RF]C|[BM]R))?'+r'.*'
        rematch=re.findall(pat, buildnum, re.I)
        typematch=re.search(r'^.*(([RF]C|[BM]R)([0-9]+)?).*$',buildnum,re.I)
        if typematch:
            print( "this is build_type",typematch.group(1))
            pass
        else:
            
            print( "it not build_type")
        if rematch:
            #print "Garnet is matched",rematch[-1]
            version=re.sub(r'^[\._\-]+|[\._\-]+$','', rematch[-1])
            if '.' in version:
                majorversion=version.strip()
            elif '_' in version:
                if len(version.split('_')) > 1:
                    majorversion=version.split('_')[-2].strip()
                    minorversion=version.split('_')[-1].strip()
            else:
                majorversion=version.strip()
        else:
            print( "No match :( ")
            
        if majorversion:
            if typematch:
                print( "this is build_type",typematch.group(1))
                majorversion=typematch.group(1)+"::"+majorversion
            if minorversion:
                return [majorversion,minorversion]
            else:
                return [majorversion]
    
    #NAVYA NEW CODE IS ADDED HERE
    def compare_version(self,excelbuildnum,mailbuildnum):
        latest=None
        mailmajortype=None
        print( "EXCELBUILDNUM",excelbuildnum)
        print( "MAILBUILDNUM",mailbuildnum)
        if (excelbuildnum):
            if mailbuildnum:
                min_length=self.get_minimumlength(len(excelbuildnum),len(mailbuildnum))
                print( "minimum length",min_length)
                for i in range(min_length):
                    if "::" in excelbuildnum[i]:
                        excelmajor=excelbuildnum[i].split('::')[-1]
                        
                        excelbuildtype=excelbuildnum[i].split('::')[0]
                    else:
                        excelmajor=excelbuildnum[i]
                    if "::" in mailbuildnum[i]:
                        mailmajor=mailbuildnum[i].split('::')[-1]
                        mailmajortype=mailbuildnum[i].split('::')[0]
                    else:
                        mailmajor=mailbuildnum[i]
                    print( "BEFORE CONVERSION TO STRING",excelmajor,mailmajor)
                    excelmajor=str(excelmajor)
                    mailmajor=str(mailmajor)
                    print( "AFTER CONVERSION TO STRING",excelmajor,mailmajor)
                    value=self.compare_digits_new(excelmajor, mailmajor)
                    print( "this is value of compare",value,type(value))
                    if len(value) == 1:
                        print( "THIS IS FALSE DATA",value[0])
                        latest=value[0]
                        break
                    
                    if not value[0] and len(value) > 1:
                        print( "THIS IS FALSE AND EQUAL")
                        latest=False
                        
                    if type(value) != bool and len(value) > 1:
                        latest=value[0]
                        print( "NOW VALUE of 2ARRAY",latest)
                    else:
                        latest=value[0]
                    
            else:
                latest=False
        else:
            latest=True
        
        if (mailmajortype == 'MR' or mailmajortype == 'BR' or mailmajortype == 'FC' or mailmajortype == 'RC'):
            print( "BRRRRR TYPE")
            if not latest:
                latest=True
        print( "Compare_Version LATEST VALUE",latest)
        if(excelbuildnum):
            for i in range(len(excelbuildnum)):
                if "::" in excelbuildnum[0]:
                    excelmajor=excelbuildnum[0].split('::')[-1]
                    excelbuildtype=excelbuildnum[0].split('::')[0]
                else:
                    excelmajor=excelbuildnum[0]
        else:
            latest=True
            print( " I am Here",excelbuildnum,latest)
        if(mailbuildnum):
            
            if "::" in mailbuildnum[0]:
                mailmajor=mailbuildnum[0].split('::')[-1]
                mailmajortype=mailbuildnum[0].split('::')[0]
            else:
                mailmajor=mailbuildnum[0]
        if(excelbuildnum and mailbuildnum):
            print( "excelbuildnum:", excelmajor, "mailbuildnum:", mailmajor)
            value=self.compare_digits_new(excelmajor, mailmajor)
            print( "this is value of compare",value,type(value))
            
            if type(value) != bool and len(value) > 1:
                latest=value[0]
                print( "NOW VALUE of 2ARRAY",latest)
            else:
                latest=value
                    
        if (mailmajortype == 'MR' or mailmajortype == 'BR' or mailmajortype == 'FC' or mailmajortype == 'RC'):
            print( "BRRRRR TYPE")
            if not latest:
                latest=True
        print( "final value of latest",latest)
        return latest
            
    #===========================================================================
    # def compare_version(self,excelbuildnum,mailbuildnum):
    #     latest=None
    #     mailmajortype=None
    #     print( "excelbuildnum:", excelbuildnum, "mailbuildnum:", mailbuildnum
    #     if(excelbuildnum):
    #         if "::" in excelbuildnum[0]:
    #             excelmajor=excelbuildnum[0].split('::')[-1]
    #             excelbuildtype=excelbuildnum[0].split('::')[0]
    #         else:
    #             excelmajor=excelbuildnum[0]
    #     else:
    #         latest=True
    #     if(mailbuildnum):
    #         if "::" in mailbuildnum[0]:
    #             mailmajor=mailbuildnum[0].split('::')[-1]
    #             mailmajortype=mailbuildnum[0].split('::')[0]
    #             print( "MAILMAJORTYPE::;",mailmajortype
    #         else:
    #             mailmajor=mailbuildnum[0]
    #     
    #     if(excelbuildnum and mailbuildnum):
    #             #print "excelbuildnum:", excelmajor, "mailbuildnum:", mailmajor
    #             value=self.compare_digits_new(excelmajor, mailmajor)
    #             print( "this is value of value",value,type(value)
    #             
    #             if type(value) != bool and len(value) > 1:
    #                 latest=value[0]
    #                 print( "NOW VALUE of 2ARRAY",latest
    #             else:
    #                 latest=value
    #                 
    #     if (mailmajortype == 'MR' or mailmajortype == 'BR' or mailmajortype == 'FC' or mailmajortype == 'RC'):
    #         
    #         if not latest:
    #             latest=True
    #     #print "latest Value is ",latest
    #     return latest
    #===========================================================================
    
    
    def compare_version_old(self,excelbuildnum,mailbuildnum):
        latest=None
        mailmajortype=None
        if len(excelbuildnum) == len(mailbuildnum):
            #print "Both are of same length. Hence can be compared",excelbuildnum[0],mailbuildnum[0]
            if "::" in excelbuildnum[0]:
                excelmajor=excelbuildnum[0].split('::')[-1]
                excelbuildtype=excelbuildnum[0].split('::')[0]
            else:
                excelmajor=excelbuildnum[0]
            if "::" in mailbuildnum[0]:
                mailmajor=mailbuildnum[0].split('::')[-1]
                mailmajortype=mailbuildnum[0].split('::')[0]
            else:
                mailmajor=mailbuildnum[0]
            value=self.compare_digits(excelmajor, mailmajor)
            if value:
                latest=value
            else:
                if len(excelbuildnum) > 1:
                    #print 'i m in else condn'
                    excelbuildnum[1]=excelbuildnum[1].replace('-','')
                    mailbuildnum[1]=mailbuildnum[1].replace('-','')
                    latest=self.compare_digits(excelbuildnum[1], mailbuildnum[1])
                else:
                    #print "There is only one condition"
                    latest=value
                    
        if (mailmajortype == 'MR'):
            if not latest:
                latest=True
        #print "latest Value is ",latest
        return latest
        
    def get_minimumlength(self,firstlength,secondlength):
        min=None
        if int(firstlength) < int(secondlength):
            min=firstlength
        elif int(firstlength) > int(secondlength):
            min=secondlength
        else:
            min=firstlength
        
        return min
                          
    def compare_digits(self,buildnumber1,buildnumber2):
        if( '.' in buildnumber1 and '.' in buildnumber2):
            length=self.get_minimumlength(len(buildnumber1.split('.')),len(buildnumber2.split('.')))
            for i in range(length):
                print( "this is number",buildnumber1.split('.')[i],buildnumber2.split('.')[i])
                value=self.compare_digits(buildnumber1.split('.')[i],buildnumber2.split('.')[i])
                print( "This is compare_digits value",value)
                if value:
                    #print "latest is build date"
                    latest=value
                    break
            else:
                latest=value
                
        elif( '-' in buildnumber1 and '-' in buildnumber2):
            length=self.get_minimumlength(len(buildnumber1.split('-')),len(buildnumber2.split('-')))
            for i in range(length):
                #print "this is number",buildnumber1.split('-')[i],buildnumber2.split('-')[i]
                value=self.compare_digits(buildnumber1.split('-')[i],buildnumber2.split('-')[i])
                if value:
                    #print "latest is build date"
                    latest=value
                    break
            else:
                latest=value
        
        else:
            print( "this is plain number")
            if(int(buildnumber1) >= int(buildnumber2)):
                print( "buildnumber1",buildnumber1," is greater than ",buildnumber2)
                latest = False
            else:
                print( "buildnumber1",buildnumber1," is lesser than ",buildnumber2)
                latest = True
        return latest
    
    
    
    def compare_digits_new(self,buildnumber1,buildnumber2):
        if( '.' in buildnumber1 and '.' in buildnumber2):
            length=self.get_minimumlength(len(buildnumber1.split('.')),len(buildnumber2.split('.')))
            for i in range(length):
                print( "this is number",buildnumber1.split('.')[i],buildnumber2.split('.')[i])
                value=self.compare_digits_new(buildnumber1.split('.')[i],buildnumber2.split('.')[i])
                #print "THIS IS VALUE",value,len(value)
                if not isinstance(value, (int, float)):
                    if value[0] and (len(value) == 1):
                        print( "latest is build date")
                        latest=[value[0]]
                        break
                elif not value[0] and len(value) > 1:
                    print( "NOT BOOLEAN and LENGTH is Greater Than 1")
                    latest=[True]
                    break
                else:
                    latest=[value[0]]
                    break
                #===============================================================
                # else:
                #     latest=value
                #     break
                #===============================================================
            else:
                latest=[value[0]]
                
        elif( '-' in buildnumber1 and '-' in buildnumber2):
            length=self.get_minimumlength(len(buildnumber1.split('-')),len(buildnumber2.split('-')))
            value=[]
            for i in range(length):
                print( "this is number",buildnumber1.split('-')[i],buildnumber2.split('-')[i])
                value=self.compare_digits_new(buildnumber1.split('-')[i],buildnumber2.split('-')[i])
                #if value:
                if value[0] and (len(value) == 1):
                    print("latest is build date")
                    latest=[value[0]]
                    break
                elif not value[0] and len(value) > 1:
                    latest=[True]
                    break
                else:
                    latest=[value[0]]
                    break
            else:
                latest=[value[0]]
        
        else:
            print( "this is plain number")
            if(int(buildnumber1) >= int(buildnumber2)):
                print( "buildnumber1",buildnumber1," is greater than ",buildnumber2)
                #latest = False
                latest = [False]
                eflag=False
                print( "latest value",latest)
                
            elif(int(buildnumber1) == int(buildnumber2)):
                print( "both numbers are equal",buildnumber1,buildnumber2)
                latest = [False,"Equal"]
                eflag="Equal"
                print( "latest value",latest,eflag)
            else:
                print( "buildnumber1",buildnumber1," is lesser than ",buildnumber2)
                latest = [True]
                print( "latest value",latest)
        return latest
    #===========================================================================
    # def compare_digits_new(self,buildnumber1,buildnumber2):
    #     
    #     if('.' in buildnumber1 or '.' in buildnumber2):
    #         flist=buildnumber1.split('.')
    #         slist=buildnumber2.split('.')
    #         #print "length of buildnumber1",flist,len(flist)
    #         #print "length of buildnumber2",slist,len(slist)
    #         min_length=self.get_minimumlength(len(flist),len(slist))
    #         #print "this is length list",min_length
    #         for i in range(min_length):
    #             #print "this is number",flist[i],slist[i]
    #             value=self.compare_digits_new(flist[i],slist[i])
    #             if value[0] and (len(value) == 1):
    #                 #print "latest is build date",slist[i]
    #                 latest=value[0]
    #             if not value[0] and len(value) > 1:
    #                 print( "this is 2 elements array"
    #                 latest=True
    #             else:
    #                 latest=value[0]
    #             break 
    #         else:
    #             latest=value[0]
    #     elif('-' in buildnumber1 or '-' in buildnumber2):
    #         flist=buildnumber1.split('-')
    #         slist=buildnumber2.split('-')
    #         min_length=self.get_minimumlength(len(flist),len(slist))
    #         for i in range(min_length):
    #             #print "this is number",flist[i],slist[i]
    #             value=self.compare_digits_new(flist[i],slist[i])
    #             if value[0] and (len(value) == 1):
    #                 #print "latest is build date",slist[i]
    #                 latest=value[0]
    #             if not value[0] and len(value) > 1:
    #                 print( "It is 2 elements array"
    #                 latest=[True]
    #             else:
    #                 latest=value[0]
    #             break 
    #         else:
    #             latest=value[0]
    #     else:
    #         if(int(buildnumber1) > int(buildnumber2)):
    #             print( "buildnumber1",buildnumber1," is greater than ",buildnumber2
    #             latest = [False]
    #             
    #         elif (int(buildnumber1) == int(buildnumber2)):
    #             print( "buildnumber1",buildnumber1," is EQUAL WITH ",buildnumber2
    #             latest = [False,"Equal"]
    #         else:
    #             print( "buildnumber1",buildnumber1," is lesser than ",buildnumber2
    #             latest = [True]
    #             
    #     return latest
    #===========================================================================
    
            
    def update_cell(self, sheet, rownumber, columnnumber, url, buildnumber):
        '''
        REQUIRES:
        
        Input sheet: type excel worksheet
        index: type integer holds worksheets's cell count
        url: type string holds actual build update link
        buildnumber thype string holds link name
        
        PROMISE:
        to update perticular cell in excel with latest url with build number if available in mails
        Output: returns None
        '''
        print( "URL:::",url)
        print( "BUILD NUMBER:::",buildnumber,"ROWNUM::::",rownumber,"COLNUM::",columnnumber)
        url=str(url)
        buildnumber=str(buildnumber)
        sheet.Cells(rownumber,'C').Value=''
        sheet.Cells(rownumber,'C').Value = '=HYPERLINK("{0}","{1}")'.format(url,buildnumber)
        sheet.Cells(rownumber,columnnumber).Value = '=HYPERLINK("{0}","{1}")'.format(url,buildnumber)
        print( "Cells updated with data",sheet.Cells(rownumber,'B').Value,sheet.Cells(rownumber,'C').Value)
        
    def createhtmltable(self,rowdata):
        html='<TABLE cellpadding="4" style="border: 1px solid #000000; border-collapse: collapse;" border="1">'
        html=html+'''<TR bgcolor="Orange">
                  <TD>BUILD DATES</TD> 
                  <TD>SL NO</TD>
                  <TD>ASSET NAME/VERSION</TD>
                  <TD>BUILDURL</TD>
                 </TR>'''
        color='LightPink'
        for key,value in rowdata.items():
            print( "this is key date and length of data",key,len(value))
            html=html+'''<TR bgcolor="{0}">
         <TD rowspan={1}>{2}</TD>'''.format(color,len(value),key)
            i=1
            for assetname,url in value.items():
                html=html+'''<TD bgcolor="{0}">{1}</TD><TD bgcolor="{2}">{3}</TD><TD bgcolor="{4}">{5}</TD>'''.format(color,i,color,assetname,color,url)
                html=html+'</TR>'
                i=i+1
        html=html+'</TABLE>'
        return html
    
    def createhtmltable_old(self,tabledata):
        #t.HTML.Table()
        t=HTML.Table(header_row=HTML.TableRow(['SL NO','ASSETNAME/VERSION', 'BUILDURL'],bgcolor='orange'))
        
        for bdate,assets in tabledata.items():
            t.rows.append(HTML.TableRow(['BUILD DATE :'+bdate], attribs={'align': 'center','bgcolor': 'pink'}))
            i=1
            for productname,producturl in assets.items():
                t.rows.append(HTML.TableRow([i,productname, producturl], attribs={'align': 'center','bgcolor': 'Aqua'}))
                i=i+1
            
        htmlcode=str(t)
        print( htmlcode)
        return htmlcode

    
    def send_mails(self,recipient,message,attachment,**kwargs):
        mailid=recipient.replace(',',';')
        outlook=win32com.client.Dispatch("Outlook.Application")
        msg=outlook.Createitem(0)
        msg.SentOnBehalfOfName=self.configdict['COMMON']["OUTLOOKMAILID"]   
        msg.Subject="[Current Builds Automation] " + message
        msg.To=mailid
        strbody = """<H3><B>Hi Team,</B></H3> 
              {0}.<br>
              Please refer attached logs for more details about the issue.<br><br><br>
              <br>Note: This is System Generated Mail.Please Do Not respond<br><br>
              """.format(message)       
        signature = "<br><B>Thank You</B></br><br>Mphasis RDL team</br>"
        updatebody=''
        notupdatebody=''
        if(kwargs):
            inputdict=kwargs
            print( "this is input dictionary",inputdict)
            if inputdict.has_key('updated'):
                updatemsg= inputdict['updated'][0]
                updatedtable=inputdict['updated'][1]
                updatebody="<B>{0}</B>.<br>{1}<br><br>".format(updatemsg,updatedtable)
            if inputdict.has_key('notupdated'):
                notupdatedmsg=inputdict['notupdated'][0]
                notupdatedtable=inputdict['notupdated'][1]
                notupdatebody="<B>{0}</B>.<br>{1}<br><br>".format(notupdatedmsg,notupdatedtable)
                
        if updatebody and notupdatebody:
            body=strbody+updatebody+notupdatebody+signature
        elif updatebody and not notupdatebody:
            body=strbody+updatebody+signature
        elif not updatebody and notupdatebody:
            body=strbody+"Since Excel has data with latest build version.Builds are not updated<br><br>"+notupdatebody+signature
        else:
            body=strbody+signature
        msg.HTMLBody=body
        msg.Attachments.Add(attachment)
        msg.Send()    
    
    def getnotupdatedlist(self,totalbuilds,updatedbuilds):
        print( "total counts of total data",len(totalbuilds))
        print( "total count of updatedata",len(updatedbuilds))
        notupdatedbuilds={}
        for build_date,assetvalue in totalbuilds.items():
            print( "build_date",build_date)
            if updatedbuilds.has_key(build_date):
                print( "This build date is present and updated",build_date)
                print( "asssetvalue",type(assetvalue),assetvalue)
                for name,url in assetvalue.items():
                    if updatedbuilds[build_date].has_key(name):
                        print( "This is product name is updated in excelsheet")
                    else:
                        if not notupdatedbuilds.has_key(build_date):
                            notupdatedbuilds.update({build_date:{}})
                        notupdatedbuilds[build_date].update({name:url})
                
            else:
                if not notupdatedbuilds.has_key(build_date):
                    notupdatedbuilds.update({build_date:{}})
                print( "not updated data",assetvalue)
                notupdatedbuilds[build_date].update(assetvalue)

        
        return notupdatedbuilds
    
    #def updatefinalbuilddict(self,subname,key,excel_type,build_date,builddata):
    def updatefinalbuilddict(self,subname,key,excel_type,build_date,url,buildnum):
        print( "UPDATEDDATA::::",url,buildnum)
        #self.writelog("UPDATEDDATA::::::::::"+str(subname)+"::build_date:::"+str(build_date)+":::BUILDDATA:::"+ str(builddata))
        if self.FINALBUILDS[excel_type][subname][build_date].has_key(key):
            print( "KEY PRESENT",key)
            wfbuildnum = self.getbuild_number(self.FINALBUILDS[excel_type][subname][build_date][key][1])
            #currebntbuildnum=self.getbuild_number(builddata[1])
            currebntbuildnum=self.getbuild_number(buildnum)       
            latest=self.compare_version(wfbuildnum, currebntbuildnum)
            #if (latest[0]):
            if latest:
                #self.FINALBUILDS[excel_type][subname][build_date][key]=builddata
                self.FINALBUILDS[excel_type][subname][build_date][key]=(url,buildnum)
        else:
            print( "KEY NOT PRESENT",self.FINALBUILDS[excel_type][subname][build_date])
            #self.FINALBUILDS[excel_type][subname][build_date][key]=builddata
            self.FINALBUILDS[excel_type][subname][build_date][key]=(url,buildnum)
        
    def check_exel_open_or_not(self, application):
        '''
        REQUIRES: 
        Input: psfile which a powershell script contains code to check excel application is already running or not
        
        PRMOMISE:
        returns the status of excel application of the local machine where script is triggered
        Output: return boolean
        '''
        self.writelog('Running to check {} application status: '.format(application))
        command = 'PowerShell -ExecutionPolicy RemoteSigned -command "& { $ProcessActive = Get-Process Excel -ErrorAction SilentlyContinue;  if($ProcessActive -eq $null){return $False} else{return $True} }"'
        result = subprocess.Popen(command, stdout=subprocess.PIPE)
        result = result.communicate()[0].strip()
        return result
    
    def build_url(self,mailobj, product_type,excel_type, build_type, other_assets, build_date):
        '''
        REQUIRES:
        Input: 
            outlook: outlook opened object to open already filtered mails to parse
            subject: subject name of the mail to be opened for parsing
            subname: is a string like SOFTWARES, FIRMWARES etc 
            exceltype: is a string type which determines which excel to be opened and updated
            buidtype: input type is string determines RC or normal build types
            software_assets: input type dict contains legacy and new version of lists of asset names
            count: input type integer to keep old and new mails to avoid data loss due to multiple mails conflicts
        
        PROMISE:
        
        method matches the specific build types and constructs dictionary of build types and udpates to self.FINALBUILD variable
        Output: dictionary of tuples of build type urls and build number details
        
        '''
        try:
            self.writelog("Coming inside Build Firmware URL function")                        
            if(isinstance(mailobj.body, unicode)):
                data = unicodedata.normalize('NFKD', mailobj.body).encode('ascii','ignore')
                #data = unicodedata.normalize('NFKD', message.body).encode('ascii','ignore')
            else:
                data = mailobj.body.encode('ascii','ignore')
                #data = message.body.encode('ascii','ignore')
        except:
            self.writelog("this is build_url function")
            self.writelog("Error: Unable to open outlook or outlook not configured!")
            print( "Error: Unable to open outlook or outlook not configured!")
            exit()
        else:
            print( "Coming inside Build OTHER URL function",mailobj.subject,build_type)
            datacontent = data.splitlines()
            sub=re.search(re.escape(product_type), mailobj.subject, re.I)
            if sub:
                subflag=sub.group(0)
            else:
                subflag=None
            #newpat=r'file:///(.*'+re.escape(self.configdict['URLNAMES'][product_type])+ r'(.*))'
            newpat=r'file:///(.*'+re.escape(self.configdict['URLNAMES'][product_type])+ r'(.*))'+r'|http(s)?://(.*'+re.escape(self.configdict['URLNAMES'][product_type])+r'.*)'
            self.create_ifnotexist_excel_type_product_type(excel_type, product_type, build_date)
            for asset in other_assets[self.NORMAL]:
                asset=asset.lower()
                print( "asset name",asset)
                for i in range(len(datacontent)):
                    build_match=re.search(newpat, datacontent[i], re.I)
                    if build_match:
                        print( "This is build match",build_match.group(0) )#Changed from 1 to 0 -Navya)
                        url=re.sub(r'[">].*$','',build_match.group(0)).lower() #Changed from 1 to 0 -Navya
                        print( "This is URL",url)
                        if "http" in url:
                            print( "this is http url")
                            name=os.path.basename(url).strip("dmg")
                        else:
                            name=url.split("\\")[-2]
                            name=re.sub("%20", " ", name.strip())
                        print( "THIS IS NAME",name)
                        if subflag: url=subflag.lower()+"::"+url
                        finalurl=url.replace(subflag.lower()+"::","")
                        #NAVYA : NEW CODE ADDED FOR MAC
                        if product_type == "MAC":
                            if build_type:
                                buildnumber=build_type+" "+name
                            else:
                                buildnumber=name
                            updatedata=[finalurl,buildnumber]
                            print( "THIS IS FINAL URL and Build NUMBER",buildnumber,finalurl)
                            self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)
                                
                        if product_type == "WJA"  or product_type == "JAC" or product_type == "DSS":
                            #pat=r'([\._\d\-]+)[^a-zA-Z]'
                            pat=r'([^a-zA-Z%20][\._\d\-]+)' #NAVYA new code added
                            alphpat=r'[^\d\W]+'
                            product_match=re.findall(alphpat, name, re.I)
                            if product_match:
                                temp=''
                                if len(product_match) > 1:
                                    for i in product_match:
                                        if i:
                                            temp=temp+" "+i
                                    productname=temp
                                else:
                                    productname=product_match[0]
                            else:  
                                productname=name
                            print( "BASIC PRODUCTNAME",productname)
                            if build_type:
                                if build_type in os.path.basename(url):
                                    buildno=os.path.basename(url).split(build_type)[0]
                                    print( "THIS IS BUILD NUMBER",buildno)
                                else:
                                    buildno=os.path.basename(url)
                                    print( "THIS IS NONBUILD NUMBER",buildno)
                                    fbuildno=re.search(pat, buildno, re.I)
                                    if fbuildno:
                                        finalno=re.sub("_","",fbuildno.group(1).strip())
                                        finalno=re.sub("%","",finalno.strip())
                                        buildno=finalno.strip()
                                        buildnumber=build_type+" "+productname+" "+buildno
                                    else:
                                        print( "productnameeeeeeeee",productname,build_type)
                                        buildnumber=build_type+" "+productname
                            else:
                                buildno=os.path.basename(url)
                                print( "buildno",buildno)
                                fbuildno=re.search(pat, buildno, re.I)
                                if fbuildno:
                                    print( "this is final buildddddddddddd",fbuildno.group(0))
                                    finalno=re.sub("_","",fbuildno.group(0).strip())
                                    finalno=re.sub("%","",finalno.strip())
                                    #===========================================
                                    # if (product_type == "WJA"):#NEW CODE ADDED
                                    #     print( "finalno",buildno
                                    #     buildname=buildno.split('%')[0]
                                    #     buildnum=buildno.split('build')[-1]
                                    #     print( "FINAL DATA",buildname,buildnum
                                    #     buildnum=buildnum.strip('-')
                                    #     buildnumber=buildname+" "+buildnum
                                    #     print( "FINAL buildnumber",buildnumber
                                    #===========================================
                                    #===========================================
                                    # else: 
                                    #     buildno=finalno.strip()
                                    #     buildnumber=productname+" "+buildno
                                    #===========================================
                                    buildno=finalno.strip()
                                    buildnumber=productname+" "+buildno
                                else:
                                    buildnumber=productname
                            print( "FINAL BUILD NUMBER",buildnumber)
                            updatedata=[finalurl,buildnumber]
                            #print "this is flag",product_type
                            flag=product_type.lower().strip()
                            if product_type == "DSS":
                                print( "this is asset name",asset)
                                dss_pat=r'.*\b'+re.escape(flag)+r'(\d+)?\b.*'+r'|(.*'+re.escape('Digital')+r'\s*'+re.escape('send')+r'.*)'
                                flag_match=re.search(dss_pat, asset, re.I)
                            if product_type == "WJA":
                                print( "this is asset name",asset)
                                wja_pat=r'.*\b'+re.escape(flag)+r'.*'+r'|(.*'+r'Web\s*Jet\s*Admin'+r'(\d+)?\b.*)'
                                flag_match=re.search(wja_pat, asset, re.I)
                            else:
                                flag_match=re.search(r'.*\b'+re.escape(flag)+r'.*', asset, re.I)
                            print( "after making lower case flag=",flag,"========",asset)
                            if flag_match:
                                print( "flag_match assets matched are",flag_match.group(0))
                                numpat=r'([\._\d\-]+)[^a-zA-Z]?'
                                number_pat=re.search(numpat, flag_match.group(0), re.I)
                                if product_type == 'DSS':
                                    if number_pat:
                                        assetno=number_pat.group(1).rstrip('.')
                                        print( "asset number and its type",type(assetno),assetno,assetno.split('.')[0])
                                        print( "build number and its type",type(buildno),buildno,buildno.split('.')[0])
                                        result=self.compare_digits_new(str(assetno.split('.')[0]), str(buildno.split('.')[0]))
                                        #print "RESULT",result,len(result)
                                        if isinstance(result, (int, float)):
                                        #if result[0]:
                                            print( "there is no asset to match",assetno)
                                            self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)
                                        else:
                                            #self.updatefinalbuilddict(product_type, asset, excel_type, build_date, updatedata)
                                            self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)
                                            #finaldict[exceltype][flag][asset]=updatedata
                                        break
                                
                                pflag=url.split("::")[0]
                                finalurl=url.replace(subflag.lower()+"::","") 
                                # NEW CODE TO AVOID MATCH OF "FP" KEYWORD IN SERVER NAME FOR WJA -NAVYA
                                #fp_pat=r'^(?!'+re.escape(product_type.lower())+r'::file:///\\'+re.escape('FP')+r'[^\\]*)'#|(\b\\'+re.escape('FP')+r'(\d+)?[^\.\\])'
                                fp_pat=r'\\(\b'+re.escape('FP')+r'(\d+)?[^a-zA-Z])'
                                asset_feature_pat=re.escape('feature')+r'\s*'+re.escape('pack')+r'$'
                                assetfeature_match=re.search(asset_feature_pat, asset, re.I)
                                print( 'THIS IS WJA URL',finalurl,product_type)
                                #fp_pat=r'^(?!file:///\\'+re.escape('FP')+r'[^\\]*)|(\b\\'+re.escape('FP')+r'(\d+)?[^\.\\])'
                                fp_match=re.search(fp_pat, url, re.I)
                                if assetfeature_match:
                                    print( " I am HERE",asset)
                                    if fp_match:
                                        print( "This is feature pack for wja URL",fp_match.group(1))
                                        buildnumber=fp_match.group(1)+" "+os.path.basename(url)
                                        if build_type:
                                            buildnumber=build_type+" "+buildnumber
                                        updatedata=[finalurl,buildnumber]
                                        if subflag.lower() == pflag.lower():
                                            #self.updatefinalbuilddict(product_type, asset, excel_type, build_date, updatedata)
                                            self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)
                                    break
                                        
                                else:
                                    print( "NO FEATURE PACK",asset)
                                    if not fp_match:
                                        if subflag.lower() == pflag.lower():
                                            print( "THERE IS NO FEATURE PACK",buildno)
                                            #self.updatefinalbuilddict(product_type, asset, excel_type, build_date, updatedata)
                                            self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)
                            else:
                                print( "FLAG NOT MATCHED")
                            #featurepack_match=re.search(re.escape(flag)+r'(?!'+re.escape('featurepack')+r')', url, re.I)    
                        if product_type == 'LOCKSMITH':
                            build_digit=os.path.basename(url)
                            digit_pat=r'([\._\d\-]+)[^a-zA-Z]'
                            digit_match=re.search(digit_pat, build_digit, re.I)
                            if digit_match:
                                build_no=digit_match.group(0)
                                leftmatch=re.search(r'_([\d\.\-]+)', build_no, re.I)
                                if leftmatch:
                                    print( "THIS IS LEFT MATCH",leftmatch.group(0).strip('_'))
                                    build_num=leftmatch.group(0).strip('_')
                            else:
                                #print "This string does not have number"
                                temp=0
                                for x in range(5):
                                    #print "i m here in locksmith"
                                    buildnum_pat=re.escape(build_digit)+r'[_\d\.]+'
                                    num_match=re.search(buildnum_pat, datacontent[i-temp], re.I)
                                    if num_match:
                                        pass
                                        #print "build no is print(ed in previous line",num_match.group(0)
                                    temp+=1
                                build_num=num_match.group(0)
                                
                            if build_type:
                                buildnumber=build_type+" "+build_num
                            else:
                                buildnumber=build_num
                            print( "locksmith build no",buildnumber)
                            builddata=[finalurl,buildnumber]
                            #self.updatefinalbuilddict(product_type, asset, excel_type, build_date, builddata)
                            self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)

                                
                        if product_type == "UPD":
                            assetname=os.path.basename(url)
                            
                            if build_type:
                                buildnumber=build_type+" "+name
                            else:
                                buildnumber=assetname
                            word="tools"
                            upd_match=re.search(re.escape(product_type), asset, re.I)
                            finalurl_match=re.search(r'(.*('+re.escape(self.configdict['CUSTOMASSETS']["UPD"])+r'[\w\d\-_\.]+)([\\]{1}'+re.escape('spo')+')?)', finalurl, re.I)
                            if upd_match:
                                print( "I M IN UPD PLACEEEEEEEEEEEEEEEEEEEEEEE",asset,assetname)
                                driver_match=re.search(re.escape('driver'), asset, re.I)
                                #print "this is urllll",url
                                if driver_match:
                                    if word not in finalurl:
                                        #print "this is nottttttt tool"
                                        if finalurl_match:
                                            print( "FINAL BUILDNAME AND URL NAME IS FOUND",finalurl_match.group(1),finalurl_match.group(2))
                                            buildnumber=finalurl_match.group(2)
                                            finalurl=finalurl_match.group(1)
                                        
                                        updatedata=[finalurl,buildnumber]
                                        self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)
                                flag_match=re.search(r'tool(s)?', asset, re.I)
                                if flag_match:
                                    if word in finalurl:
                                        updatedata=[finalurl,buildnumber]
                                        self.updatefinalbuilddict(product_type, asset, excel_type, build_date, finalurl,buildnumber)
                                else:
                                    pass
                            
                                    
    
    def build_firmware_url(self, mailobj, excel_type, build_type, firmware_assets, build_date):
        '''
        REQUIRES:
        Input: 
            outlook: outlook opened object to open already filtered mails to parse
            subject: subject name of the mail to be opened for parsing
            subname: is a string like SOFTWARES, FIRMWARES etc 
            exceltype: is a string type which determines which excel to be opened and updated
            buidtype: input type is string determines RC or normal build types
            software_assets: input type dict contains legacy and new version of lists of asset names
            count: input type integer to keep old and new mails to avoid data loss due to multiple mails conflicts
        
        PROMISE:
        
        method matches the specific build types and constructs dictionary of build types and udpates to self.FINALBUILD variable
        Output: dictionary of tuples of build type urls and build number details
        '''
        try:
            #outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
            #message = outlook.Folders("navya.km@mphasis.com").Folders("Inbox").Items("FW: [New Jedi FW] [15N2] - 4/20  23.5 BR (part 2)")
            
            self.writelog("Coming inside Build Firmware URL function")                        
            if(isinstance(mailobj.body, unicode)):
                data = unicodedata.normalize('NFKD', mailobj.body).encode('ascii','ignore')
                #data = unicodedata.normalize('NFKD', message.body).encode('ascii','ignore')
            else:
                data = mailobj.body.encode('ascii','ignore')
                #data = message.body.encode('ascii','ignore')
        except:
            self.writelog("this is BUILD_FIRMWARE url function")
            self.writelog("Error: Unable to open outlook or outlook not configured!")
            print( "Error: Unable to open outlook or outlook not configured!")
            exit()
        else:
            serverpattern=r'file:///\\\\(.*)'+re.escape(self.configdict['URLNAMES'][self.FIRMWARES])+r'\\.*'
            #print "this is build_dateee",build_date,mailobj.subject
            flag=False
            datacontent = data.splitlines()
            for i in range(len(datacontent)):
                datacontent[i]=re.sub(r'\s+','', datacontent[i])
                print( "LINESSSSSSSS",datacontent[i])
                urlmobj = re.search(serverpattern,datacontent[i],re.I)
                if urlmobj:
                    for fm in firmware_assets[self.NORMAL]:
                        fm=fm.split('firmware')[0].encode('utf-8').strip()
                        print( "this is fm",fm)
                        
                        
                        url=re.sub(r'[">].*$','',urlmobj.group(0)).lower()
                        url=url.strip("\\") #Navya:: New Code ADDED
                        url=url.strip()
                        #if url has signed bdl
                        signedpattern=re.search(re.escape('signed.bdl')+r'$', url, re.I)
                        if signedpattern:
                            #print "URL HAS SIGNED BDL",signedpattern.group(0)
                            #print "BEFORE URL",url
                            bdlname=os.path.basename(url)
                            print( "This is bdlname",bdlname)
                            newurl = re.sub(r'\\'+bdlname+'$', '', url)
                            #newurl=url.strip(bdlname)
                            #newurl=newurl.strip("\\") #Navya:: New Code ADDED
                            #newurl=newurl.strip()
                            print( "STRIPED URL",newurl)
                        else:
                            
                            newurl=url
                            print( "NORMAL URL",newurl)
                        if(build_type):
                            #print "BUILD_TYPE::",build_type
                            buildnum = build_type + " " + os.path.basename(newurl)
                        else:
                            buildnum = os.path.basename(newurl)
                        updatedata=[newurl,buildnum]
                        
                        productmatch=re.search(r'.*\b'+re.escape(fm)+r'\b.*', urlmobj.group(0), re.I)
                        if productmatch:
                            
                            #To match if words starts like eVA: 
                            prev_pat= r'\b(^e)?'+re.escape(fm)+r'\s*(\/)?(WF)?\s*:\s*'
                            
                            self.create_ifnotexist_excel_type_product_type(excel_type, self.FIRMWARES, build_date)
                            check_match=re.search(prev_pat, datacontent[i], re.I)
                            if check_match:
                                #print "this is product name",check_match.group(0)
                                line_match=re.search(serverpattern,datacontent[i],re.I)
                                if line_match:
                                    print( "Both are in same line")
                                    skey=check_match.group(0).replace(':','').lower()
                                    #print "same key",skey        
                                    if '/wf' in skey:
                                        #print "WorkFlow in same line",skey
                                        swfkey=skey.split('/wf')[0]
                                        swfkey=swfkey+"wffirmware"
                                        #NEW CODE
                                        self.updatefinalbuilddict(self.FIRMWARES,swfkey, excel_type, build_date, updatedata)
                                        #self.updatefinalbuilddict(self.FIRMWARES,swfkey, excel_type, build_date, url,buildnum)
                                    skey=skey+"firmware"
                                    #self.updatefinalbuilddict(self.FIRMWARES,skey, excel_type, build_date, url,buildnum)
                                    self.updatefinalbuilddict(self.FIRMWARES,skey, excel_type, build_date, updatedata)
                                break
                            else:
                                prev=0
                                while True:
                                    prev+=1
                                    pre_match=re.search(prev_pat, datacontent[i-prev], re.I)
                                    if pre_match:
                                        key=pre_match.group(0).split(':')[0].strip().lower()
                                        key=key.replace(' ','')
                                        if "/wf" in key:
                                            key=key.split('/wf')[0]
                                            wfkey=key+"wffirmware"
                                            self.updatefinalbuilddict(self.FIRMWARES,wfkey, excel_type, build_date, updatedata)
                                        key=key+"firmware"
                                        self.updatefinalbuilddict(self.FIRMWARES, key, excel_type, build_date, updatedata)
                                        flag=True
                                        break
                                    if(prev == 5):
                                        break
                            if not flag:
                                print( "URL::::",newurl,"BUILDNUMBER:::",buildnum)
                                print( "this is next line format")
                                #wfpat=r'\b'+re.escape(fm)+r'\s*(/)?'+re.escape('WF')+r'\b'
                                wfpat=r'\b'+re.escape(fm)+r'\s*(\/)?(WF|4l)'+r'\b'
                                temp=0
                                flag=""
                                while True:
                                    temp +=1
                                    if int(i+temp) >= len(datacontent):
                                        #print "there is no data any more",i+temp,len(datacontent)
                                        print( "this is normal line format")
                                        nkey=fm
                                        #self.updatefinalbuilddict(self.FIRMWARES, nkey, excel_type, build_date, updatedata)
                                        self.updatefinalbuilddict(self.FIRMWARES, nkey, excel_type, build_date, newurl,buildnum)
                                        break
                                    match1=re.search(wfpat, datacontent[i+temp], re.IGNORECASE)
                                    if match1:
                                        key=match1.group(0).split()[-1].lower()
                                        keymatch=re.search(wfpat, key, re.I)
                                        #print "I M IN MATCH1"
                                        if keymatch:
                                            if '/wf' in key:
                                                key1=key.split('/wf')[0]
                                            else:
                                                key1=keymatch.group(0).split('wf')[0]
                                            
                                            
                                            normalkey=key1+"firmware"
                                            print( "NORMALKEYYYYYYY",normalkey)
                                            self.updatefinalbuilddict(self.FIRMWARES, normalkey, excel_type, build_date, newurl,buildnum)
                                            #self.updatefinalbuilddict(self.FIRMWARES, normalkey, excel_type, build_date, updatedata)
                                            if "4l" in key1:
                                                pass
                                            else:
                                                workflowkey=key1+"wffirmware"
                                                print( "WORKFLOW KEYE",workflowkey)
                                                #self.updatefinalbuilddict(self.FIRMWARES, workflowkey, excel_type, build_date, updatedata)
                                                self.updatefinalbuilddict(self.FIRMWARES, workflowkey, excel_type, build_date, newurl,buildnum)
                                        break
                                    elif(temp == 5 and not match1):
                                        #print "KEYYYYYYYYYYYYYYy",fm
                                        key=fm
                                        key=key+"firmware"
                                        #self.updatefinalbuilddict(self.FIRMWARES, key, excel_type, build_date, updatedata)
                                        self.updatefinalbuilddict(self.FIRMWARES, key, excel_type, build_date,newurl,buildnum)
                                    if(temp == 5):
                                        break

        for key,value in self.FINALBUILDS[excel_type][self.FIRMWARES][build_date].items():
            key=key.split('firmware')[0].lower()
            wkey=key+"wffirmware"
            #print "KEY AND ITS WORKFLOW",wkey
            if self.FINALBUILDS[excel_type][self.FIRMWARES][build_date].has_key(wkey.strip()):
                pass
            else:
                wkey=wkey.split('firmware')[0]
                #print "KEY TO BE UPDATED",wkey
                workflowlist=[re.sub(re.escape('firmware'), '', wf,re.I) for wf in [re.sub(r'\s+', '', k).lower() for k,v in firmware_assets[self.LEGACY].items()]]
                if wkey in workflowlist:
                    fkey=wkey+"firmware"
                    print( "UPDATEDDDDDDDDDDDDDDDDDD",fkey)
                    self.FINALBUILDS[excel_type][self.FIRMWARES][build_date][fkey]=value
#         
        print( "CONSTRUCTED BUILDSSSSSSSSSS")
        print(self.FINALBUILDS)
        
    def build_software_url(self,mailobj, excel_type, build_type, software_assets, build_date):
        '''
        REQUIRES:
        Input: 
            outlook: outlook opened object to open already filtered mails to parse
            subject: subject name of the mail to be opened for parsing
            subname: is a string like SOFTWARES, FIRMWARES etc 
            excel_type: is a string type which determines which excel to be opened and updated
            buidtype: input type is string determines RC or normal build types
            software_assets: input type dict contains legacy and new version of lists of asset names
            count: input type integer to keep old and new mails to avoid data loss due to multiple mails conflicts
        
        PROMISE:
        
        method matches the specific build types and constructs dictionary of build types and udpates to self.FINALBUILD variable
        Output: dictionary of tuples of build type urls and build number details
        
        '''
        try:
            self.writelog("Coming inside Build Software URL function")                        
            if(isinstance(mailobj.body, unicode)):
                data = unicodedata.normalize('NFKD', mailobj.body).encode('ascii','ignore')
            else:
                data = mailobj.body.encode('ascii','ignore')
        except:
            self.writelog("this is build_Software url function")
            self.writelog("Error: Unable to open outlook or outlook not configured!")
            print( "Error: Unable to open outlook or outlook not configured!")
            exit()
        else:
            #print "this is build_dateeeeeeeeeeee",build_date
            self.create_ifnotexist_excel_type_product_type(excel_type,'SOFTWARES',build_date)
            datacontent = data.splitlines()
            legacypat = r'.*'+re.escape('Legacy')+r'.*'
            for i in range(len(datacontent)):
                planetserver='boi-ftp.cscr.hp.com'
                checkhttp=r'http(s)?://'+re.escape(planetserver)+r'.*'
                httpmatch=re.search(checkhttp, datacontent[i], re.I)
                if httpmatch:
                    #print "Mail contains Planet Express link ",httpmatch.group()
                    readurl=urllib.urlopen(httpmatch.group(0))
                    soup = BeautifulSoup(readurl.read())
                    links = soup.findAll('a')
                    for link in links:
                        url=link.get('href')
                        newpat=r'(^\\\\\b'+re.escape(self.configdict['URLNAMES'][self.SOFTWARES])+r'[\w\\_\s\-\.%]+)([>"]\s*)?$'
                        match=re.search(newpat, url, re.I)
                        if match:
                            if(build_type):
                                buildnumber = build_type + " " + os.path.basename(url).strip()
                            else:
                                buildnumber = os.path.basename(url).strip()
                            updatedata=[url,buildnumber,777]
                            legacymatch=re.search(legacypat, url, re.I)
                            if legacymatch:
                                self.FINALBUILDS[excel_type][self.SOFTWARES][build_date].update(self.build_software_dictionary(self.FINALBUILDS[excel_type][self.SOFTWARES][build_date],updatedata, software_assets, 'Legacy'))
                                #softwaredict['Legacy'].append(updatedata)
                            else:
                                
                                self.FINALBUILDS[excel_type][self.SOFTWARES][build_date].update(self.build_software_dictionary(self.FINALBUILDS[excel_type][self.SOFTWARES][build_date],updatedata, software_assets, 'Discrete'))
                else:
                    #print "LINE NO: ",i,"DATA :",datacontent[i]
                    #urlmobj = re.search(r'(.*'+re.escape(self.configdict['URLNAMES'][self.SOFTWARES])+r'.*)',datacontent[i],re.I)
                    urlmobj = re.search(r'(.*'+re.escape(self.configdict['URLNAMES'][self.SOFTWARES])+r'[\w\\_\s\-\.%].*)([>"]\s*)?$',datacontent[i],re.I)
                    if urlmobj:
                        print( "URL IS MATCHED",urlmobj.group())
                        newpat1=r'\\\\\b'+re.escape(self.configdict['URLNAMES'][self.SOFTWARES])+r'\b(\\.*)([>"]\s*)?$'
                        #newpat1=r'(^\\\\\b'+re.escape(self.configdict['URLNAMES'][self.SOFTWARES])+r'\b[\w\\_\s\-\.%]+)([>"]\s*)?$'
                        match=re.search(newpat1, urlmobj.group(1), re.I)
                        if match:
                            print( "match is found",match.group(0))
                            if '"' in match.group(0):
                                print( "There is quote in url")
                                newurl=match.group(0).split('"')[0]
                                print( "NEW URL",newurl)
                            else:
                                newurl=match.group(0)
                            if(build_type):
                                #print "this is build type",build_type
                                #buildnumber = build_type + " " + os.path.basename(match.group(0)).strip()
                                buildnumber = build_type + " " + os.path.basename(newurl).strip()
                            else:
                                buildnumber = os.path.basename(newurl).strip()
                            #print "REQUIRED DATA:::",match.group(0),buildnumber
                            #buildobj.writelog("REQUIRED DATA:::"+match.group(0))
                            #updatedata = [match.group(0), buildnumber, 888 ]
                            updatedata = [newurl, buildnumber, 888 ]
                            legacymatch=re.search(legacypat, urlmobj.group(1), re.I)
                            
                            if legacymatch:
                                    self.FINALBUILDS[excel_type][self.SOFTWARES][build_date].update(self.build_software_dictionary(self.FINALBUILDS[excel_type][self.SOFTWARES][build_date], updatedata, software_assets, self.LEGACY))
                            else:
                                self.FINALBUILDS[excel_type][self.SOFTWARES][build_date].update(self.build_software_dictionary(self.FINALBUILDS[excel_type][self.SOFTWARES][build_date], updatedata, software_assets, self.NORMAL))
                                #softwaredict['Discrete'].append(updatedata)
                            
            
            print( "This Software dictionary built from mail",len(self.FINALBUILDS[excel_type][self.SOFTWARES][build_date]))
            return self.FINALBUILDS
        
    def build_software_dictionary(self,softdict,urldata,software_assets,flag):
        #pprint(software_assets)
        #pprint(urldata)
        #print "inside build software dictionary"
        if(flag == self.LEGACY):
            
            for key in software_assets[self.LEGACY]:
                sdata=re.sub(r'_(\s+)?Legacy(\s+)?Discrete','',key,re.I)
                sdata = re.sub(r'\s+','',sdata).lower()
                sdata=sdata.split('_legacydiscrete')[0]
                #print "THIS iS LEGACY MATCH",sdata,urldata[0]
                partialmatch=r'\\\b'+re.escape(sdata.strip())+r'\b.*'
                obj=re.search(partialmatch,urldata[0].lower(),re.I)
                legpat=r'.*'+re.escape('Legacy')+r'.*'
                legmatch=re.search(legpat,urldata[0],re.I)
                if obj:
                    #print "LEGACY MATCH FOUND"
                    if legmatch:
                        
                        sdata=sdata+'_legacydiscrete'
                        if softdict.has_key(sdata):
                            print( "Key is already available in software dict",sdata)
                            oldbuild=self.getbuild_number(softdict[sdata][1])
                            newbuild=self.getbuild_number(urldata[1])
                            latest=self.compare_version(oldbuild, newbuild)
                            if latest[0]:
                                softdict[sdata]=urldata
                        else:
                            softdict[sdata]=urldata
        else:
            for key in software_assets[self.NORMAL]:
                key=key.split('discrete')[0]
                key = re.sub(r'\s+','',key).lower()
                partialmatch=r'\\\b'+re.escape(key.strip())+r'\b.*'
                legpat=r'.*'+re.escape('Legacy')+r'.*'
                legmatch=re.search(legpat,urldata[0],re.I)
                obj=re.search(partialmatch,urldata[0],re.I)
                if obj:
                    if not legmatch:
                        key=key+'discrete'
                        if softdict.has_key(key):
                            #print "Key is already available in software dict",key
                            oldbuild=self.getbuild_number(softdict[key][1])
                            newbuild=self.getbuild_number(urldata[1])
                            latest=self.compare_version(oldbuild, newbuild)
                            if latest[0]:
                                softdict[key]=urldata
                        else:
                            softdict[key]=urldata
        return softdict
    
    def search_key_list(self, datalist, searchkey):
        if(isinstance(datalist, list) and isinstance(searchkey, str) or isinstance(searchkey, unicode) and len(datalist) > 0):
            for keyword in datalist:
                matchobj = re.search(re.escape(searchkey), keyword, re.IGNORECASE)
                if(matchobj):
                    return True
            else: return False
        else:
            print( "Invalid data type arguments to the function")
            return False
    
    def update_excel(self, finalbuilds, sheetname = "Sheet1"):
        '''
        REQUIRES: 
        
        Input: filename string type contains excel file name with path
        excelstring: its a reference string to which the url's to be udpated
        sheetname: string type contains name of the excel sheet if not provided "Sheet1" is considered
        
        PROMISE:
        
        Method assumes excel data is in specific format where Column B is Asset Name and Column C 
        is Current Build and updates the latest builds if present and saves the updated excel sheet.
        Returns: None
        '''
        self.updateddata={}
        print( "^" * 75)
        if(isinstance(finalbuilds, dict) and finalbuilds):
            print( "excellist while updating excel: ", self.excellist)
            for excel_type in finalbuilds.keys():
                print( "BUILD_CYCLE: ", excel_type)
                cycle_result = self.search_key_list(self.excellist, excel_type)
                print( "cycle_result",cycle_result)
                
                if(cycle_result):
                    excelfile = self.scriptpath +'\\'+ self.EXCELDIR +'\\'+excel_type + "_CurrentBuilds.xlsm"
                    excel=os.path.basename(excelfile).strip()
                    self.writelog("Downloading: " + excelfile)
                    download_result = self.do_request_sharepoint(event = "download", filename = excel)
                    #download_result=True
                    if(download_result == True or download_result == 'True'):
                        self.writelog("downloading of {} file successful".format(excelfile))
                        print( "This excel_type: {}_CurrentBuilds.xlsm present in share point list".format(excel_type))
                        self.writelog("This excel_type: {}_CurrentBuilds.xlsm present in share point list".format(excel_type))
                        if(os.path.exists(excelfile)):
                            locked = threading.Lock()
                            locked.acquire()
                            openxlobj = self.open_excel(excelfile, sheetname)
                            if(openxlobj and len(openxlobj) == 4):
                                print( excelfile + " FILE OPENED SUCCESSFULLLY...")
                                print( openxlobj, ":opened excel obj list")
                                for product_type in finalbuilds[excel_type].keys():
                                    print( "PRODUCT_TYPE: ",product_type)
                                    product_result = self.search_key_list(self.master_dict[excel_type].keys(), product_type)
                                    #print "product result after search", product_result
                                    if(product_result):
                                        sorteddate = finalbuilds[excel_type][product_type].keys()
                                        if(sorteddate):
                                            if(len(sorteddate) >= 2):
                                                builtdates = [datetime.datetime.strptime(x, "%m/%d/%y %H:%M:%S") for x in sorteddate]
                                                #print 'BEFORE SORTING DATES', builtdates
                                                builtdates.sort()
                                                sorteddate = []
                                                for gdate in builtdates:
                                                    sorteddate.append(gdate.strftime("%x 00:00:00"))
                                                #print "SORTED DATES FROM OLD TO NEW: ", sorteddate
                                            for build_date in sorteddate:
                                                
                                                for asset_name in finalbuilds[excel_type][product_type][build_date].keys():
                                                    
                                                    row_number = 0
                                                    if(self.master_dict[excel_type][product_type][self.NORMAL].has_key(asset_name)):
                                                        #self.master_dict[excel_type][product_type][self.NORMAL].update({asset_name : finalbuilds[excel_type][product_type][build_date][asset_name]})
                                                        #print "assetvalueeeeeeeeeeeeeee of masterdict:", self.master_dict[excel_type][product_type][self.NORMAL][asset_name]
                                                        row_number = self.master_dict[excel_type][product_type][self.NORMAL][asset_name]
                                                        #print "AASSSET NAME FROM MASTER DICT : ", asset_name, self.master_dict[excel_type][product_type][self.NORMAL][asset_name]
                                                        current_asset_name_xl = openxlobj[2].Cells(row_number, 2) # HARDCODED BECAUSE 2rd COLUMN IS THE CURRENT ASSET NAMES
                                                        current_build_value_xl = openxlobj[2].Cells(row_number, 3) # HARDCODED BECAUSE 3rd COLUMN IS THE CURRENT BUILDS COLUMN
                                                        mailbuildcellvalue = finalbuilds[excel_type][product_type][build_date][asset_name]
                                                        xlbuildnumber = self.getbuild_number(str(current_build_value_xl))
                                                        mailbuildnumber = self.getbuild_number(mailbuildcellvalue[1])
                                                        #print "tyupe of xl and mail build numbers:", type(xlbuildnumber), type(mailbuildnumber)
                                                        latest = self.compare_version(xlbuildnumber, mailbuildnumber)
                                                        #latest=True
                                                        print( "XLBUILD NUMBER: AND MAILBUILDNUMBER : ",xlbuildnumber, mailbuildnumber, 'LATEST: ', latest)
                                                        self.writelog(str(current_asset_name_xl)+" Value Comparsion:" +"OLD XLBUILD NUMBER: "+ str(xlbuildnumber) + "\tNEW MAILBUILDNUMBER: "+str(mailbuildnumber)+"\tLATEST VALUE: "+str(latest))
                                                        
                                                        if(latest): 
                                                            data = finalbuilds[excel_type][product_type][build_date][asset_name]
                                                            createflag, column_number = self.create_search_column(openxlobj[2], build_date, searchstring = "Asset Name")
                                                            print( "ALREADY CREATED FLAG: ", createflag, "COLUMN_NUMBER: ", column_number, build_date,  excel_type)
                                                            print( "ROW---COLUMN DETAILS::",row_number,column_number,data[0],data[1])
                                                            self.update_cell(openxlobj[2], row_number, column_number, data[0], data[1])
                                                            updatedasset=excel_type+'-'+asset_name
                                                            print( "this is updated assetttttttttt",updatedasset)
                                                            if self.updateddata.has_key(build_date):
                                                                self.updateddata[build_date].update({updatedasset:data[0]})
                                                            else:
                                                                self.updateddata.update({build_date:{}})
                                                                self.updateddata[build_date].update({updatedasset:data[0]})
                                                            print( "UPDATED DATA",self.updateddata)
                                                        #else: print( "asset_name not present in row: ", row_number
                                                    
                                                        
                                                    elif(self.master_dict[excel_type][product_type][self.LEGACY].has_key(asset_name)):
                                                            row_number = self.master_dict[excel_type][product_type][self.LEGACY][asset_name]
                                                            #print "row number in legacy builds:", row_number
                                                            #print "AASSSET NAME FROM MASTER DICT : ", asset_name, self.master_dict[excel_type][product_type][self.NORMAL][asset_name]
                                                            current_asset_name_xl = openxlobj[2].Cells(row_number, 2) # HARDCODED BECAUSE 2rd COLUMN IS THE CURRENT ASSET NAMES
                                                            current_build_value_xl = openxlobj[2].Cells(row_number, 3) # HARDCODED BECAUSE 3rd COLUMN IS THE CURRENT BUILDS COLUMN
                                                            #print "CURRENT ASSET NAME:", current_asset_name_xl, "current_build_value: ", current_build_value_xl
                                                            #mailbuildcellvalue = openxlobj[2].Cells(row_number, column_number).Value
                                                            mailbuildcellvalue = finalbuilds[excel_type][product_type][build_date][asset_name]
                                                            #print "GGGGGGG:", current_build_value_xl, mailbuildcellvalue[1]
                                                            xlbuildnumber = self.getbuild_number(str(current_build_value_xl))
                                                            mailbuildnumber = self.getbuild_number(mailbuildcellvalue[1])
                                                            latest = self.compare_version(xlbuildnumber, mailbuildnumber)
                                                            #latest=True
                                                            print( "LEGACY SIDE :::: XLBUILD NUMBER: AND MAILBUILDNUMBER : ",xlbuildnumber, mailbuildnumber, "LATEST:", latest)
                                                            self.writelog(str(current_asset_name_xl)+" Value Comparsion:" +"OLD XLBUILD NUMBER: "+ str(xlbuildnumber) + "\tNEW MAILBUILDNUMBER: "+str(mailbuildnumber)+"\tLATEST VALUE: "+str(latest))
                                                            
                                                            #if(latest[0]):
                                                            if latest:
                                                                #print "this is latest build updating:",latest[0]
                                                                data = finalbuilds[excel_type][product_type][build_date][asset_name]
                                                                createflag, column_number = self.create_search_column(openxlobj[2], build_date, searchstring = "Asset Name")
                                                                print( "ALREADY CREATED FLAG: ", createflag, "COLUMN_NUMBER: ", column_number, build_date,  excel_type)
                                                                print( "ROW---COLUMN DETAILS::",row_number,column_number,data[0],data[1])
                                                                self.update_cell(openxlobj[2], row_number, column_number, data[0], data[1])
                                                                updatedasset=excel_type+'-'+asset_name
                                                                
                                                                if self.updateddata.has_key(build_date):
                                                                    self.updateddata[build_date].update({updatedasset:data[0]})
                                                                else:
                                                                    self.updateddata.update({build_date:{}})
                                                                    self.updateddata[build_date].update({updatedasset:data[0]})
                                                                print( "this is updated assetttttttttt",updatedasset)
                                                                print( "UPDATED DATA",self.updateddata)
                                                            
                                                    else: print( "Asset_name: {} not present in excel".format(asset_name))
                                    else:
                                        print( "product_type: {} not present in excel file: {}_CurrentBuilds.xlsm".format(product_type, excel_type))
                            else:
                                print( "EXCEL FILE: ", excelfile , " Open error")
                                self.writelog("EXCEL FILE: "+ excelfile + " Open error")
                            self.close_excel(openxlobj[0], openxlobj[1], openxlobj[3],excel_type)
                            locked.release()
                            upload_result = self.do_request_sharepoint(event="upload", filename = excel)
                            #upload_result=True
                            if(upload_result == True or upload_result == 'True'):
                                self.writelog("Successfully uploaded "+ excelfile)
                                print( "this is totaldata",totaldata)
                                print( "this is updated data",self.updateddata)
                                print( "Successfully uploaded "+ excelfile)
                                if self.updateddata:
                                    nodata=self.getnotupdatedlist(totaldata, self.updateddata)
                                    htmldata=self.createhtmltable(self.updateddata)
                                    if nodata:
                                        noupdate=self.createhtmltable(nodata)
                                        self.send_mails(recipient=self.configdict['COMMON']['RECIPIENTID'], message="Latest builds are successfully updated in Excel sheet in sharepoint",attachment=self.logfile,updated=["List of updated builds",htmldata],notupdated=["List of not updated Builds",noupdate])
                                    else:
                                        self.send_mails(recipient=self.configdict['COMMON']['RECIPIENTID'], message="Latest builds are successfully updated in Excel sheet in sharepoint",attachment=self.logfile,updated=["List of updated builds",htmldata])
                                        pass

                            else:
                                self.writelog("Uploading of {} to Sharepoint failed".format(excelfile))
                                print( "Uploading of {} to Sharepoint failed".format(excelfile))
                                self.send_mails(recipient=self.configdict['COMMON']['RECIPIENTID'], message="Error:: Uploading of '{}' to Sharepoint failed".format(excel),attachment=self.logfile)
                    else:
                        self.writelog("Downloading of {} to Sharepoint failed".format(excelfile))
                        print( "Downloading of {} to Sharepoint failed".format(excelfile)   )
                else:
                    print( "This excel_type: {}_CurrentBuilds.xlsm not present in share point list".format(excel_type))
                    self.writelog("This excel_type: {}_CurrentBuilds.xlsm not present in share point list".format(excel_type))
            #exact point to paste
            
                    
    def search_date_column(self, sheet, build_date, searchstring = '[a-zA-Z]{5,}'):
        '''
        REQUIRES:
        
        Input: excelfile string type path to excel to be passed
        sheetname: string type which sheet in excel to be opened
        searchstring: type string where data header begins
        
        PROMISE:
        
        Method used to open and read excel file and builds dictionary of headers and values (win32com.client module is required)
        NOTE: Script is dynamic finds which row data begins and builds dict once row exists (first data existing row considered as headers)
        Returns: dict
        '''
        '''lists = [excel,book,sheet,result]'''
        
        #sheet.DisplayAlerts = True
        used = sheet.UsedRange
        headercount = 0
        for row in range(used.Rows.Count):
            headercount += 1
            mobj = re.search(re.escape(searchstring)+ r'|'+ re.escape(build_date), str(used.Rows[row]), re.I)
            if(mobj):
                column_count = 0
                for i in range(used.Columns.Count):
                    value = str(sheet.Cells(row+1,i+1).Value)
                    column_count += 1
                    column_obj = re.search(re.escape(build_date), value)
                    if(column_obj):
                        print( column_obj.group(),"columncounts: ",column_count,"headercount: ", headercount,"value: ", value)
                        print( "FOUND: "+str(column_count))
                        return column_count
                break
        return column_count
                        
    def create_search_column(self, sheet,  build_date, searchstring = "Asset Name"):
        used = sheet.UsedRange
        headercount = 0
        columnnumber = 0
        cflag = False
        for row in range(used.Rows.Count):
            headercount += 1
            mobj = re.search(re.escape(searchstring), str(used.Rows[row]), re.I)
            if(mobj):
                column_count = 0
                #print "ASSET NAME IS PRESENT...----------------"
                for i in range(used.Columns.Count):
                    value = str(sheet.Cells(row+1,i+1).Value)
                    column_count += 1
                    column_obj = re.search(re.escape(build_date), value)
                    if(column_obj):
                        print( "BUILD DATE IS ALREADY PRESENT: "+str(column_count),' >>> ' ,build_date)
                        columnnumber = column_count
                        cflag = True
                        break
                break
        print( "Already created column FLAG? : ", cflag)
        if(cflag is not True):
            print( "BUILD DATE NOT FOUND HENCE... CREATED COLUMN WITH BUILD DATE: >>> ", build_date)
            sheet.Columns("E").EntireColumn.Insert()
            sheet.Cells(headercount,"E").Value = build_date
            columnnumber = 5 # 'E' column where columns being inserted using macros
        return cflag, columnnumber

    def open_excel(self, excelfile, sheetname = "Sheet1"):
        '''
        REQUIRES:
        
        Input: excelfile string type path to excel to be passed
        sheetname: string type which sheet in excel to be opened
        
        PROMISE:
        
        Method used to open and read excel file (win32com.client module is required)
        NOTE: Script is generic finds which row data begins and builds dict once row exists (first data existing row considered as headers)
        Returns: dict
        '''
        if(os.path.exists(excelfile)):
            result = self.check_process_status(application = 'excel.exe')
            print( "excel running status;",result)
            try:
                excel = win32com.client.Dispatch("Excel.Application")
            except:
                print( "Unable to open Excel application, Check if the application is installed and working fine.")
                os._exit(1)
            else:
                try:
                    abspath = os.path.abspath(excelfile)
                    book = excel.Workbooks.Open(abspath)
                    if(sheetname == "Sheet1"):
                        sheetname = book.ActiveSheet.name
                        print( "this is active sheet name...", sheetname)
                except:
                    print( "Excel file is already opened please close then run the script!")
                    os._exit(1)
                else:
                    finaldata = []
                    excel.Visible = True
                    try:
                        sheet = book.Sheets(sheetname)
                    except:
                        print( 'line 1903, "{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                        book.Save() #saving the workbook
                        if(result is True or result == 'True'): #here an already unsaved excel is running
                            book.Close(True)
                            #excel.Quit()
                        else:
                            excel.Quit()
                            #book.Close(True) #saving out excel without altering opened excel
                        return
                    else:
                        excel.DisplayAlerts=True
                        #used=sheet.UsedRange
                        lists = [excel,book,sheet,result]
        if(lists):
            return lists
        else: return False

    def close_excel(self, excel, book, result,excel_type):
        print( 'CLOSING EXCELLLLLLLLLLLLLLLLL',excel_type)
        book.Save()
        if(result is True or result == 'True'): #here an already unsaved excel is running
            #excel.Quit()
            book.Close(True)
        else:
            #book.Close(True) #saving out excel without altering opened excel
            excel.Quit()
        return
        
def main():
    '''main function to trigger the script and update excels'''
    print( "INSIDE MAIN FUNCTION...")
    global totaldata
    totaldata={}
    buildobj = CreateBuildUpdates()
    buildobj.writelog("Create Builds object successfully created.")
    msgobjlist = buildobj.read_mails()
    if(msgobjlist):
        print( "THIS IS MAIL MESSAGE LIST:")
        for item in msgobjlist:
            print( 'MAIL SUBJECTS: ', item.subject)
        print( "$$$$$END OF MAIL MESSAGE LIST$$$$$$")
        print( "THERE ARE TOTAL ", len(msgobjlist), " MAILS PRESENT")
        finalbuildlinks = buildobj.extract_url(msgobjlist)
        print( "MASTER DICT HAS BUILT----")
        #pprint (buildobj.master_dict)
        print( "END OF MASTER DICT$$$")
        
        buildobj.writelog("There are {0} build mails present at {1} time slot.".format(str(len(msgobjlist)), buildobj.configdict['COMMON']['MAILREADLIMIT']))
        if (finalbuildlinks):
            print( "FINALBUILD LINKS>>>")
            print(finalbuildlinks)
            print( "("* 100)
            fout = open(buildobj.logfile,"a+")
            print("*"*100+"FINALBUILD LINKS"+"*"*100, stream = fout)
            print(buildobj.FINALBUILDS, stream = fout)
            print("*"*100+"END OF FINALBUILD LINKS"+"*"*100, stream = fout)
            fout.close()
            print( "END OF FINALBUILD LINKS$$$")
            
            for cyclename,build_date in buildobj.FINALBUILDS.items():
                for productname,bdate in build_date.items():
                    for specific_date,assetdata in bdate.items():
                        for assetname,asseturl in assetdata.items():
                            finalkey=cyclename+"-"+assetname
                            buildurl=asseturl[0]
                            if totaldata.has_key(specific_date):
                                totaldata[specific_date].update({finalkey:buildurl})
                            else:
                                totaldata.update({specific_date:{}})
                                totaldata[specific_date].update({finalkey:buildurl})
            buildobj.update_excel(finalbuildlinks, sheetname = "CurrentBuilds")
        else:
            buildobj.writelog("NO UPDATES AVAILABLE TO UPDATE IN EXCEL")
            print( "NO UPDATES AVAILABLE TO UPDATE IN EXCEL")
    else:
        buildobj.writelog("There are No build mails present at {0} time slot.".format(buildobj.configdict['COMMON']['MAILREADLIMIT']))
        print( "MAIN ENDS "+"%" * 200)
    print( "END OF MAIN FUNCTION...")
    
if(__name__ == "__main__"):
    '''
    Main Block where script execution begins if this script is triggered
    '''
    main()
    
#####END OF MAIN######
