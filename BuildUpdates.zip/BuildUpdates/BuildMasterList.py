'''
Created on May 19, 2015

@author: kmna
'''
import xlrd as xlrd

try:
    
    import os
    import re
    import pdb
    import time
    import pickle
    import copy
    import datetime
    import subprocess
    import unicodedata
    import collections
    import win32com.client
    import urllib
    #import HTML
    from library import *
    from pprint import pprint
    from BuildUpdates import CreateBuildUpdates
    from BeautifulSoup import BeautifulSoup, SoupStrainer
    
    
except ImportError as e:
    print("The current module is not installed in your machine, Error: ", e)
    exit()
    
class BuildMasterList(ReadData, Reportlogs):
    def __init__(self, **kwargs):
        '''
        REQUIRES
        
        Input:kwargs: dictionaries of input key value pair format
        
        PROMISE
        
        This constructor class constructs dict from internal buildconfig.cfg file and provides a platform to build urls
        Output:None
        '''
        if(kwargs):
            self.kwargs = kwargs
        self.check()
        
    def check(self):
            '''
            REQUIRES:
            
            Input: an internal config file buildconfig.cfg
            
            PROMISE:
            
            to construct config dictionary to make build extraction easy mapping
            Output: Constructs Config Dictionary if config file exists
            '''
            self.FIRMWARES = 'FIRMWARES'
            self.SOFTWARES = 'SOFTWARES'
            self.WJA = 'WJA'
            self.UPD = 'UPD'
            self.DSS = 'DSS'
            self.JAC = 'JAC'
            self.MAC = 'MAC'
            self.LOCKSMITH = 'LOCKSMITH'
            self.SHAREPOINT = 'SHAREPOINT'
            self.URL = 'URL'
            self.DOCFOLDER = 'DOCFOLDER'
            self.USERNAME = 'USERNAME'
            self.PASSWORD = 'PASSWORD'
            self.TARGETFILE = "Printer_Automation.docx"
            self.EXCELDIR = "excel_builds"
            self.CONFIGFILE = "Buildconfig.cfg"   #THIS IS A STANDARD INTERNAL REFERENCE CONFIG FILE
            self.PICKLEOBJ = "pickleobj.pkl"
            self.NORMAL = 'NORMAL'
            self.OTHERBUILDS = 'OTHERBUILDS'
            self.WORKFLOW = 'WF'
            self.LEGACY = 'LEGACY'
            self.DISCRETE = 'DISCRETE'
            self.DOWNLOADFLAG = False
            
            Reportlogs.__init__(self,dirname = "BuildMaster", filename = "buildlog")
            self.FINALBUILDS = {}
            self.master_dict = {}
            self.excellist = [] #["14P4_CurrentBuilds","15P2_CurrentBuilds","15N2_CurrentBuilds","15R2_CurrentBuilds","14N3_CurrentBuilds"]
            
            self.scriptpath, self.scriptname = os.path.split(os.path.abspath(__file__))
            self.excelflag = None
            
            if(os.path.exists(self.scriptpath+'\\'+self.CONFIGFILE) and os.path.getsize(self.scriptpath+'\\'+self.CONFIGFILE) > 50):
                self.writelog(self.CONFIGFILE +" Present in the Script path")
                self.configdict = self.readText(file = self.scriptpath+'\\'+self.CONFIGFILE, headerpattern = '^\s*[A-Z]+\s*$', datapattern = '^.*[=].*$')
                print("_____________CONFIGURATION FILE CONTENTS:__________________________________")
                fout = open(self.logfile,"a+")
                pprint(self.configdict, stream = fout)
                fout.close()
                pprint(self.configdict)
                print("___________________________________________________________________________")
                self.powershell = "C:\\Windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe"
                self.psscript = "SharePointAccess.ps1"
                #BuildObj=CreateBuildUpdates()
                self.excellist = self.do_request_sharepoint(event = "list")
                #self.excellist =['14N1_CurrentBuilds.xlsm', '14N2_CurrentBuilds.xlsm', '14N3_CurrentBuilds.xlsm', '14P4_CurrentBuilds.xlsm', '15R1_CurrentBuilds.xlsm', '15P2_CurrentBuilds.xlsm', '15N2_CurrentBuilds.xlsm', '15R3_CurrentBuilds.xlsm', '15N4_CurrentBuilds.xlsm', '15P4_CurrentBuilds.xlsm', '1603_CurrentBuilds.xlsm']
                #self.excellist = ["14P4_CurrentBuilds.xlsm","15P2_CurrentBuilds.xlsm","15N2_CurrentBuilds.xlsm","15R1_CurrentBuilds.xlsm","14N1_CurrentBuilds.xlsm","14N2_CurrentBuilds.xlsm","14N3_CurrentBuilds.xlsm","14N4_CurrentBuilds.xlsm","15R3_CurrentBuilds.xlsm","15N4_CurrentBuilds.xlsm"]
                print("EXCEL FILE LIST FROM SHARE POINT: ",self.excellist)
                if(len(self.excellist) == 0):
                    self.writelog("Error: No Excel files from sharepoint. Cannot proceed with BuildUpdate.")
                    print("Error: No Excel files from sharepoint. Cannot proceed with BuildUpdate")
                    self.send_mails(self.configdict['COMMON']["RECIPIENTID"], message="Error:: Excel sheets are not available in sharepoint link",attachment=self.logfile)
                    os._exit(1)
                self.writelog("Successfully built config data structure.\nexcellist present")
                
                if(os.path.exists(self.scriptpath+"\\"+ self.EXCELDIR)):
                    self.writelog("Excel builds path exists: " + self.scriptpath + "\\" + self.EXCELDIR)
                else:
                    self.writelog("Excel Builds path does not exist! creating the path:")
                    print("Excel Builds path doesnot exists! creating the path:")
                    currentdir = os.getcwd()
                    os.chdir(self.scriptpath)
                    os.mkdir(self.EXCELDIR)
                    os.chdir(currentdir)
                            
                if(os.path.exists(self.scriptpath +"\\"+ self.PICKLEOBJ)):
                    pickle_result = self.check_pickle_old_or_new(self.scriptpath +"\\"+ self.PICKLEOBJ)
                    pickle_result=False
                    if(pickle_result): #pickle_result is true if the pickle data object file is older than MAILREADLIMIT
                        self.writelog("Master List pickle is older than given time limit.Creating new Master pickle")
                        for excel in self.excellist:
                            excelfile = self.scriptpath+"\\"+ self.EXCELDIR +"\\"+ excel
                            download_result=self.do_request_sharepoint(event = "download", filename = excel)
                            #download_result=True
                            if(download_result == True or download_result == 'True'):
                                self.writelog("downloading of {} file successful".format(excelfile))
                                if(os.path.getsize(excelfile) > 0):
                                    print("Downloaded excel {} has data".format(excelfile))
                                    self.writelog( "Downloaded excel {} has data".format(excelfile)) 
                        self.master_dict = self.build_master_dict(self.excellist)
                        if(self.master_dict):
                            self.DOWNLOADFLAG = True
                            
                            self.pickle_dump(self.scriptpath +"\\"+ self.PICKLEOBJ, self.master_dict)
                    else:
                        print("This is Latest pickle")
                        self.master_dict = self.pickle_load(self.scriptpath +"\\"+ self.PICKLEOBJ)
                        pprint(self.master_dict)
                        
                else:
                    for excel in self.excellist:
                            excelfile = self.scriptpath+"\\"+ self.EXCELDIR +"\\"+excel
                            download_result=self.do_request_sharepoint(event = "download", filename = excel)
                            #download_result=True
                            if(download_result == True or download_result == 'True'):
                                self.writelog("downloading of {} file successful".format(excel))
                                #print("this is excel file size:",os.path.getsize(excelfile)
                                if(os.path.getsize(excelfile) > 0):
                                    print("Downloaded excel {} has data".format(excel))
                                    self.writelog( "Downloaded excel {} has data".format(excel))
                            else:
                                self.writelog("downloading of {} file failed".format(excel))
                    self.master_dict = self.build_master_dict(self.excellist)
                    if(self.master_dict):
                        #print("sel...........:",self.master_dict)
                        self.DOWNLOADFLAG = True
                        self.pickle_dump(self.scriptpath +"\\"+ self.PICKLEOBJ, self.master_dict)
                print("*"*50+"MASTER DICT STRUCTURE"+"*"*50)
                pprint(self.master_dict)
    
            else:
                self.writelog("Error: An internal Config file \"{}\" does not exist!\nPlease keep the configuration file in the existing script path.".format(self.CONFIGFILE))
                print("Error: An internal Config file \"{}\" does not exist!\nPlease keep the configuration file in the existing script path.".format(self.CONFIGFILE))
                os._exit(1)

    def do_request_sharepoint(self, event, filename = None):
        '''
        REQUIRES:
        
        Input: event type string contains actions like list,download,upload
        file: type string contains excel file name to be uploaded or downloaded
        
        PROMISE:
        to get list of files retrieved from share point or downloading, uploading of specific file to sharepoint
        Output: return Boolean
        '''
        pat=r'Connection Failure'
        message="SharePoint Server '{}' is Down.Check the Network connectivity".format(self.configdict[self.SHAREPOINT][self.URL])
        if (event == "list"):
            command=self.powershell,'-InputFormat',' None', '-ExecutionPolicy', 'Remotesigned', self.scriptpath+"\\"+self.psscript,"-SPUrl \""+self.configdict[self.SHAREPOINT][self.URL]+"\"", " -docfolder \""+self.configdict[self.SHAREPOINT][self.DOCFOLDER]+"\"",  "-flag '"+event+"'", "-User '"+self.configdict[self.SHAREPOINT][self.USERNAME]+"'", "-Password  '"+self.configdict[self.SHAREPOINT][self.PASSWORD]+"'","-logfile '"+self.logfile+"'"
            result = subprocess.Popen(command,stdout=subprocess.PIPE)
            outputlines=result.communicate()
            match=re.search(pat,str(outputlines[0]),re.IGNORECASE)
            if match:
                print("SharePoint Server is Down")
                self.send_mails(self.configdict['COMMON']["RECIPIENTID"],message,attachment=self.logfile)
                os._exit(1)
            else:
                print("SharePoint Server is fine")
                data=[x.strip() for x in str(outputlines[0]).split(',') if x.strip()]
                for item in data:
                    if(item.endswith('.xlsm')):
                        self.excellist.append(item.strip())
                if(self.excellist):
                    print("Final Excel List:", self.excellist)
                    self.writelog("excel file list is present in sharepoint") 
            return self.excellist
        elif(event == "upload" or event == "download"):  #TO DOWNLOAD AND UPLOADING THE GIVEN MACRO ENABLED EXCEL FILE
            command = self.powershell,' -InputFormat',' None', ' -ExecutionPolicy', 'Remotesigned', self.scriptpath+"\\"+self.psscript,"-SPUrl \""+self.configdict[self.SHAREPOINT][self.URL]+"\"", " -docfolder \""+self.configdict[self.SHAREPOINT][self.DOCFOLDER]+"\"", "-TargetFolder  "+self.scriptpath+"\\"+self.EXCELDIR,"-flag '"+event+"'"," -TargetFile  '"+filename+"'", " -User '"+self.configdict[self.SHAREPOINT][self.USERNAME]+"'", " -Password  '"+self.configdict[self.SHAREPOINT][self.PASSWORD]+"'","-logfile '"+self.logfile+"'"
            result = subprocess.Popen(command,stdout=subprocess.PIPE)
            outputlines=result.communicate()
            match=re.search(pat,str(outputlines[0]),re.IGNORECASE)
            if match:
                print("SharePoint Server is Down")
                self.send_mails(self.configdict['COMMON']["RECIPIENTID"],message,attachment=self.logfile)
                os._exit(1)
            else:
                if(result):
                    flagobj = re.search(r'True', str(outputlines[0]), re.IGNORECASE|re.MULTILINE)
                    if(flagobj):
                        return True
                    else:
                        return False
    
    def build_master_dict(self, excellist):
        master_dict = {}
        currentyear=datetime.datetime.now().year
        final_year=currentyear%100
        sheetname = 'CurrentBuilds'
        column = 2
        for excel in excellist:
            #if excel.startswith(str(final_year)):
                cycle = excel.split('_')[0]
                excelfilepath = self.scriptpath + '\\' + self.EXCELDIR+'\\' + excel
                if(os.path.exists(excelfilepath)):
                    #excel_dict=self.build_master_dictionary(excelfilepath, cycle, sheetname,column)
                    excel_dict=self.build_master_dictionary_win32(excelfilepath, cycle, sheetname, 'Asset',column)
                    if (excel_dict):
                        master_dict.update(excel_dict)
                #master_dict.update(self.build_master_dictionary(excelfilepath, cycle, sheetname, "Asset Name",column))
        return master_dict
    
    def pickle_dump(self, pickle_file, data):
        filehandler = open(str(pickle_file), "wb")
        pickle.dump(data, filehandler)
        filehandler.close()
        
    def pickle_load(self, pickle_file):
        if(os.path.exists(pickle_file)):
            file = open(pickle_file, 'rb')
            object_file = pickle.load(file)
            #print("*" * 100)
            #pprint(object_file)
            file.close()
            #print("$" * 100)
            return object_file
        else:
            print("No pickle file path present")
    
    def check_pickle_old_or_new(self, picklefile):
        if(os.path.exists(picklefile)):
            currentdate = datetime.datetime.today()
            hourgap = re.sub(r'\s*[a-zA-Z_.]+$','',self.configdict['COMMON']['MASTERLIST'])
            gap = datetime.timedelta(hours = int(hourgap))
            creationtime = datetime.datetime.strptime(time.ctime(os.path.getmtime(picklefile)), '%a %b %d %H:%M:%S %Y')
            difftime = currentdate - creationtime
            if(difftime > gap):
                print("difference time more than gap hours", hourgap)
                flag = True
                #master_dict = self.get_master_dict()
            else:
                #print("pickle is not too old just load pickle object")
                flag = False
            return flag
        
    def build_master_dictionary(self,excelfile, excel_type, sheetname, column):
        try:
            workbook = xlrd.open_workbook(excelfile)
            worksheet = workbook.sheet_by_name(sheetname)
        except:
                print('"{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                return
        else:
            regex_dict = {}
            master_dict = collections.OrderedDict()
            
            if(master_dict.has_key(excel_type) is not True):
                master_dict.update({excel_type:{}})
            
            regex_dict.update({self.SOFTWARES : r'(' + self.LEGACY + r'(\))?)?\s*(' + self.DISCRETE + r')'})
            regex_dict.update({self.FIRMWARES : r'(' + self.WORKFLOW + r'(\))?)?\s*(Firmware|FW\s*$' + r')'})
            regex_dict.update({self.WJA : re.escape(self.WJA)+r'|Web\s*Jet\s*Admin'})
            regex_dict.update({self.JAC : re.escape(self.JAC)})
            regex_dict.update({self.DSS : r'Digital\s*send\s*(SW)?.*'})
            regex_dict.update({self.UPD : r'\b'+re.escape(self.UPD)+r'|Tool(s)?'})
            regex_dict.update({self.MAC : re.escape(self.MAC)+r'\s*(OS)?\s*'})
            regex_dict.update({self.LOCKSMITH : re.escape(self.LOCKSMITH)})
            
            for row_index in range(0, worksheet.nrows):
                assetvalue = worksheet.cell(row_index, 1).value
                if(isinstance(assetvalue, unicode)):
                    assetvalue = unicodedata.normalize('NFKD', assetvalue).encode('ascii','ignore')
                else: assetvalue.encode('utf-8')
                or_obj = re.search(r'(.*)\s+(or|and)\s+.*\s+(\w+)\s*$', assetvalue, re.IGNORECASE)
                if(or_obj):
                    #print("COMING INSIDE OR CONTIANG ASSET NAMEEEEEEEEEEEEEEEEEEEEEEE", or_obj.group(2)
                    assetvalue = or_obj.group(1).strip() + or_obj.group(3).strip()
               
                assetvalue = re.sub(r'\s+','',assetvalue.strip()).lower()
                assetvalue = assetvalue.strip()
                current_build_value = worksheet.cell(row_index, 2).value
                #print("ROW INDEXXX:", row_index+1, assetvalue#, "CURRENT BUILD VALUE:",current_build_value
                if assetvalue is not None or assetvalue != '':
                    regex_count = 0
                    for key_pattern in regex_dict.keys():
                        flag = False
                        pattern_match=re.search(regex_dict[key_pattern], assetvalue, re.IGNORECASE)
                        if pattern_match:
                            if key_pattern == self.MAC:
                                if master_dict[excel_type].has_key(self.MAC) is not True:
                                    master_dict[excel_type].update({self.MAC:{}})
                                if(master_dict[excel_type][self.MAC].has_key(self.NORMAL) is not True):
                                    master_dict[excel_type][self.MAC].update({self.NORMAL:{}})
                                master_dict[excel_type][self.MAC][self.NORMAL].update({assetvalue:row_index+1})
                                break
                            elif key_pattern == self.SOFTWARES:
                                if master_dict[excel_type].has_key(self.SOFTWARES) is not True:
                                        master_dict[excel_type].update({self.SOFTWARES:{}})
                                if(pattern_match.group(1)):
                                    if master_dict[excel_type][self.SOFTWARES].has_key(self.LEGACY) is not True:
                                        master_dict[excel_type][self.SOFTWARES].update({self.LEGACY:{}})
                                    master_dict[excel_type][self.SOFTWARES][self.LEGACY].update({assetvalue:row_index+1})
                                else:
                                    if master_dict[excel_type][self.SOFTWARES].has_key(self.NORMAL) is not True:
                                            master_dict[excel_type][self.SOFTWARES].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.SOFTWARES][self.NORMAL].update({assetvalue:row_index+1})
                                break
                                
                            elif key_pattern == self.FIRMWARES:
                                if master_dict[excel_type].has_key(self.FIRMWARES) is not True:
                                        master_dict[excel_type].update({self.FIRMWARES:{}})
                                if(pattern_match.group(1)):
                                    if master_dict[excel_type][self.FIRMWARES].has_key(self.LEGACY) is not True:
                                        master_dict[excel_type][self.FIRMWARES].update({self.LEGACY:{}})
                                    master_dict[excel_type][self.FIRMWARES][self.LEGACY].update({assetvalue:row_index+1})
                                else:
                                    if master_dict[excel_type][self.FIRMWARES].has_key(self.NORMAL) is not True:
                                            master_dict[excel_type][self.FIRMWARES].update({self.NORMAL:{}})
                                    master_dict[excel_type][self.FIRMWARES][self.NORMAL].update({assetvalue:row_index+1})
                                break
                            
                            elif key_pattern == self.WJA:
                                if master_dict[excel_type].has_key(self.WJA) is not True:
                                    master_dict[excel_type].update({self.WJA:{}})
                                if(master_dict[excel_type][self.WJA].has_key(self.NORMAL) is not True):
                                    master_dict[excel_type][self.WJA].update({self.NORMAL:{}})
                                master_dict[excel_type][self.WJA][self.NORMAL].update({assetvalue:row_index+1})
                                break
                            
                            elif key_pattern == self.UPD:
                                if master_dict[excel_type].has_key(self.UPD) is not True:
                                    master_dict[excel_type].update({self.UPD:{}})
                                if(master_dict[excel_type][self.UPD].has_key(self.NORMAL) is not True):
                                    master_dict[excel_type][self.UPD].update({self.NORMAL:{}})
                                master_dict[excel_type][self.UPD][self.NORMAL].update({assetvalue:row_index+1})
                                break
                            
                            elif key_pattern == self.DSS:
                                if master_dict[excel_type].has_key(self.DSS) is not True:
                                    master_dict[excel_type].update({self.DSS:{}})
                                if(master_dict[excel_type][self.DSS].has_key(self.NORMAL) is not True):
                                    master_dict[excel_type][self.DSS].update({self.NORMAL:{}})
                                master_dict[excel_type][self.DSS][self.NORMAL].update({assetvalue:row_index+1})
                                break
                            
                            elif key_pattern == self.JAC:
                                if master_dict[excel_type].has_key(self.JAC) is not True:
                                    master_dict[excel_type].update({self.JAC:{}})
                                if(master_dict[excel_type][self.JAC].has_key(self.NORMAL) is not True):
                                    master_dict[excel_type][self.JAC].update({self.NORMAL:{}})
                                master_dict[excel_type][self.JAC][self.NORMAL].update({assetvalue:row_index+1})
                                break
                            
                            elif(key_pattern == self.LOCKSMITH):
                                if(master_dict[excel_type].has_key(self.LOCKSMITH) is not True):
                                    master_dict[excel_type].update({self.LOCKSMITH:{}})
                                if(master_dict[excel_type][self.LOCKSMITH].has_key(self.NORMAL) is not True):
                                    master_dict[excel_type][self.LOCKSMITH].update({self.NORMAL:{}})
                                master_dict[excel_type][self.LOCKSMITH][self.NORMAL].update({assetvalue:row_index+1})
                                break
                            
                        else:
                            #print("COUNTING FOR OTHER BUILDS"
                            regex_count += 1
                        if regex_count == len(regex_dict.keys()):
                            if assetvalue != 'Asset Name' and assetvalue:
                                if master_dict[excel_type].has_key(self.OTHERBUILDS) is not True:
                                    master_dict[excel_type].update({self.OTHERBUILDS:{}})
                                if(master_dict[excel_type][self.OTHERBUILDS].has_key(self.NORMAL) is not True):
                                    master_dict[excel_type][self.OTHERBUILDS].update({self.NORMAL:{}})
                                master_dict[excel_type][self.OTHERBUILDS][self.NORMAL].update({assetvalue:row_index+1})
        return master_dict
    def build_master_dictionary_win32(self,excelfile, excel_type, sheetname,searchstring,column):
        if(os.path.exists(excelfile)):
            try:
                result = self.check_process_status(application = 'excel.exe')
                print("excel running status;",result)
                excel = win32com.client.Dispatch("Excel.Application")
                runningexcel = win32com.client.GetObject (os.path.abspath(excelfile))
            except:
                    print('Unable to open Excel application, Check if the application is installed and working fine')
                    return False
            else:
                try:
                    print("this is value of running excel",runningexcel,"********************")
                    excelpath = os.path.abspath(excelfile)
                    book = excel.Workbooks.Open(excelpath)
                    if(sheetname == "Sheet1"):
                        sheetname = book.ActiveSheet.name
                except:
                    print("Excel file is already opened please close then run the script!")
                    return
                    #os._exit(1)
                else:
                    excel.Visible = True
                    try:
                        sheet = book.Sheets(sheetname)
                    except:
                        print('"{0}" sheet name is not present in "{1}"'.format(sheetname,excelfile))
                        excel.Application.Quit() 
                        return
                    else:
                        regex_dict = {}
                        master_dict = collections.OrderedDict()
                        
                        if(master_dict.has_key(excel_type) is not True):
                            master_dict.update({excel_type:{}})
                        
                        regex_dict.update({self.SOFTWARES : r'(' + self.LEGACY + r'(\))?)?\s*(' + self.DISCRETE + r')'})
                        regex_dict.update({self.FIRMWARES : r'(' + self.WORKFLOW + r'(\))?)?\s*(Firmware|FW\s*$' + r')'})
                        regex_dict.update({self.WJA : re.escape(self.WJA)+r'|Web\s*Jet\s*Admin'})
                        regex_dict.update({self.JAC : re.escape(self.JAC)})
                        regex_dict.update({self.DSS : re.escape(self.DSS)+r'|Digital\s*send\s*(SW)?.*'})
                        regex_dict.update({self.UPD : r'\b'+re.escape(self.UPD)+r'|Tool(s)?'})
                        regex_dict.update({self.MAC : re.escape(self.MAC)+r'\s*(OS)?\s*'})
                        regex_dict.update({self.LOCKSMITH : re.escape(self.LOCKSMITH)})
                        
                        
                        excel.DisplayAlerts = True
                        used = sheet.UsedRange
                        headercount = 0
                        headers = []
                        flag = 0
                        for row in range(used.Rows.Count):
                                headercount += 1
                                #print("Row:::",row)
                                mobj = re.search(searchstring, str(used.Rows[row]), re.I)
                                if(mobj):
                                    for i in range(used.Columns.Count):
                                        value = str(sheet.Cells(row+1,i+1).Value)
                                        if(value.strip()):
                                            headers.append(value.strip())
                                        else:
                                            headers.append(None)
                                    break
                        if(not headers):
                            print('Sheet: "{0}" has no data in "{1}"'.format(sheetname,excelfile))
                            excel.Quit()
                            os._exit(1)
                        else:
                            print("This is LIST")
                            print(headers)
                            for row in range(headercount, used.Rows.Count):
                                assetvalue = sheet.Cells(row+1,column).Value
                                if(assetvalue == 'None' or assetvalue == '' or assetvalue is None):
                                    pass
                                else:
                                    if(isinstance(assetvalue, unicode)):
                                        assetvalue = unicodedata.normalize('NFKD', assetvalue).encode('ascii','ignore')
                                    else: assetvalue.encode('utf-8')
                                    or_obj = re.search(r'(.*)\s+(or|and)\s+.*\s+(\w+)\s*$', assetvalue, re.IGNORECASE)
                                    if(or_obj):
                                        #print("COMING INSIDE OR CONTIANG ASSET NAMEEEEEEEEEEEEEEEEEEEEEEE", or_obj.group(2)
                                        assetvalue = or_obj.group(1).strip() + or_obj.group(3).strip()
                                   
                                    assetvalue = re.sub(r'\s+','',assetvalue.strip()).lower()
                                    assetvalue = assetvalue.strip()
                                    current_build_value = sheet.Cells(row+1,column+1).Value
                                    #print("ROW INDEXXX:", row_index+1, assetvalue#, "CURRENT BUILD VALUE:",current_build_value
                                    if assetvalue is not None or assetvalue != '':
                                        regex_count = 0
                                        for key_pattern in regex_dict.keys():
                                            flag = False
                                            pattern_match=re.search(regex_dict[key_pattern], assetvalue, re.IGNORECASE)
                                            if pattern_match:
                                                if key_pattern == self.MAC:
                                                    if master_dict[excel_type].has_key(self.MAC) is not True:
                                                        master_dict[excel_type].update({self.MAC:{}})
                                                    if(master_dict[excel_type][self.MAC].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.MAC].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.MAC][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                elif key_pattern == self.SOFTWARES:
                                                    if master_dict[excel_type].has_key(self.SOFTWARES) is not True:
                                                            master_dict[excel_type].update({self.SOFTWARES:{}})
                                                    if(pattern_match.group(1)):
                                                        if master_dict[excel_type][self.SOFTWARES].has_key(self.LEGACY) is not True:
                                                            master_dict[excel_type][self.SOFTWARES].update({self.LEGACY:{}})
                                                        master_dict[excel_type][self.SOFTWARES][self.LEGACY].update({assetvalue:row+1})
                                                    else:
                                                        if master_dict[excel_type][self.SOFTWARES].has_key(self.NORMAL) is not True:
                                                                master_dict[excel_type][self.SOFTWARES].update({self.NORMAL:{}})
                                                        master_dict[excel_type][self.SOFTWARES][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                    
                                                elif key_pattern == self.FIRMWARES:
                                                    if master_dict[excel_type].has_key(self.FIRMWARES) is not True:
                                                            master_dict[excel_type].update({self.FIRMWARES:{}})
                                                    if(pattern_match.group(1)):
                                                        if master_dict[excel_type][self.FIRMWARES].has_key(self.LEGACY) is not True:
                                                            master_dict[excel_type][self.FIRMWARES].update({self.LEGACY:{}})
                                                        master_dict[excel_type][self.FIRMWARES][self.LEGACY].update({assetvalue:row+1})
                                                    else:
                                                        if master_dict[excel_type][self.FIRMWARES].has_key(self.NORMAL) is not True:
                                                                master_dict[excel_type][self.FIRMWARES].update({self.NORMAL:{}})
                                                        master_dict[excel_type][self.FIRMWARES][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.WJA:
                                                    if master_dict[excel_type].has_key(self.WJA) is not True:
                                                        master_dict[excel_type].update({self.WJA:{}})
                                                    if(master_dict[excel_type][self.WJA].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.WJA].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.WJA][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.UPD:
                                                    if master_dict[excel_type].has_key(self.UPD) is not True:
                                                        master_dict[excel_type].update({self.UPD:{}})
                                                    if(master_dict[excel_type][self.UPD].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.UPD].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.UPD][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.DSS:
                                                    if master_dict[excel_type].has_key(self.DSS) is not True:
                                                        master_dict[excel_type].update({self.DSS:{}})
                                                    if(master_dict[excel_type][self.DSS].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.DSS].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.DSS][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif key_pattern == self.JAC:
                                                    if master_dict[excel_type].has_key(self.JAC) is not True:
                                                        master_dict[excel_type].update({self.JAC:{}})
                                                    if(master_dict[excel_type][self.JAC].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.JAC].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.JAC][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                                elif(key_pattern == self.LOCKSMITH):
                                                    if(master_dict[excel_type].has_key(self.LOCKSMITH) is not True):
                                                        master_dict[excel_type].update({self.LOCKSMITH:{}})
                                                    if(master_dict[excel_type][self.LOCKSMITH].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.LOCKSMITH].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.LOCKSMITH][self.NORMAL].update({assetvalue:row+1})
                                                    break
                                                
                                            else:
                                                #print("COUNTING FOR OTHER BUILDS"
                                                regex_count += 1
                                            if regex_count == len(regex_dict.keys()):
                                                if assetvalue != 'Asset Name' and assetvalue:
                                                    if master_dict[excel_type].has_key(self.OTHERBUILDS) is not True:
                                                        master_dict[excel_type].update({self.OTHERBUILDS:{}})
                                                    if(master_dict[excel_type][self.OTHERBUILDS].has_key(self.NORMAL) is not True):
                                                        master_dict[excel_type][self.OTHERBUILDS].update({self.NORMAL:{}})
                                                    master_dict[excel_type][self.OTHERBUILDS][self.NORMAL].update({assetvalue:row+1})
            
            book.Close(True,excelfile)
            #excel.Quit()
            pprint(master_dict)
            return master_dict
        else:
            print(excelfile+ " Excel File path does not exists")
            os._exit(1)
    
    
def main():
    buildexcel=BuildMasterList()
    
    print("building the dictionary")
    
if(__name__ == "__main__"):
    '''
    Main Block where script execution begins if this script is triggered
    '''
    main()
